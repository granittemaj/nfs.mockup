<?php
/**
 * PAPINGU block theme.
 * Renders the approved Not For Sale design system by loading the prototype's
 * own styles.css, app.js (engine: chrome, artwork, interactions) and flags.js.
 * Built by PAPINGU L.L.C.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'after_setup_theme', function () {
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'title-tag' );
} );

add_action( 'wp_enqueue_scripts', function () {
	$uri = get_stylesheet_directory_uri();
	$ver = wp_get_theme()->get( 'Version' );

	wp_enqueue_style(
		'papingu-fonts',
		'https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,500;0,600;0,700;0,800;0,900;1,500;1,600;1,700&family=Source+Serif+4:ital,opsz,wght@0,8..60,400;0,8..60,500;0,8..60,600;1,8..60,400&display=swap',
		array(), null
	);

	// The real design system, verbatim from the approved prototype.
	wp_enqueue_style( 'papingu-styles', $uri . '/assets/css/styles.css', array(), $ver );

	// Engine: injects header/newsletter/footer, generates artwork, renders pages, handles interactions.
	wp_enqueue_script( 'papingu-flags', $uri . '/assets/js/flags.js', array(), $ver, true );
	wp_enqueue_script( 'papingu-app',   $uri . '/assets/js/app.js', array( 'papingu-flags' ), $ver, true );
} );

add_filter( 'wp_resource_hints', function ( $hints, $relation ) {
	if ( 'preconnect' === $relation ) {
		$hints[] = array( 'href' => 'https://fonts.gstatic.com', 'crossorigin' );
	}
	return $hints;
}, 10, 2 );

