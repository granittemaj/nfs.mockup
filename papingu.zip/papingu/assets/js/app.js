/* =========================================================================
   Not For Sale — site engine (no framework, no network)
   Renders shared chrome + page content, generates self-contained artwork.
   ========================================================================= */
(function(){
"use strict";
var FLAGS = window.FLAGS || {};
var FLAME = '<svg viewBox="0 0 24 24"><path d="M12 2c1.2 4.2-3 5.2-3 9.2a3 3 0 0 0 6 0c0-1.6-.8-2.7-1-3.8 2 .9 3.2 3 3.2 5.1a6.4 6.4 0 1 1-12.4 0C4.8 7 9.8 6 12 2z" fill="#fff"/></svg>';

/* ---- site config (managed in wp-admin: NFS Settings) ---- */
var CFG = window.NFS_CONFIG || {};
var LOGO_URL = CFG.logo || "https://stg.wearenotforsale.org/wp-content/uploads/2025/11/logo-1-e1781208606205.png";
var MAILCHIMP_ACTION = CFG.mailchimp || "";
var BRAND = LOGO_URL
  ? '<img class="brandlogo" src="'+LOGO_URL+'" alt="Not For Sale" style="height:30px;width:auto;display:block">'
  : '<span class="flame">'+FLAME+'</span><span class="name">Not For Sale</span>';

var slug = function(s){return s.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');};

/* ---------- category system ---------- */
var CAT = {
 "Human Trafficking":{c:"#c46f49",pal:[0,6]},
 "Social Innovation":{c:"#4f8e92",pal:[3]},
 "Social Enterprise":{c:"#4f8e92",pal:[3]},
 "Ecocide":{c:"#5b7747",pal:[2]},
 "Cyber Scams":{c:"#62808d",pal:[1,7]}
};
function catColor(c){return CAT[c]?CAT[c].c:"#F5821F";}

/* ---------- scene generator ---------- */
var PAL=[
 {s1:"#f4d9b8",s2:"#e7ad77",sun:"#f0915a",h:["#d98a52","#bf6f3e","#8f4f2c"]},
 {s1:"#dde8ee",s2:"#a9c3cf",sun:"#f4efe4",h:["#8aa2ad","#62808d","#3f5b66"]},
 {s1:"#dde7cf",s2:"#a9c191",sun:"#eef0d6",h:["#7e9a64","#5b7747","#3a5430"]},
 {s1:"#cfe6e8",s2:"#9cc6cc",sun:"#f6e7c8",h:["#79b0b0","#4f8e92","#356c70"]},
 {s1:"#f3e6c4",s2:"#e6c98a",sun:"#f4a259",h:["#cba85e","#a98742","#7a5d2c"]},
 {s1:"#e9dfe9",s2:"#c8b6c9",sun:"#f3e3ea",h:["#a591a8","#7e6781","#574258"]},
 {s1:"#fbe3d0",s2:"#f6b98e",sun:"#f58a4b",h:["#e3936a","#c46f49","#8f4d31"]},
 {s1:"#e7ecef",s2:"#cdd6db",sun:"#eef2f3",h:["#9fb0b8","#76898f","#516167"]}
];
function hash(s){var h=2166136261;for(var i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return h>>>0;}
function rng(seed){return function(){seed|=0;seed=seed+0x6D2B79F5|0;var t=Math.imul(seed^seed>>>15,1|seed);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
function hill(baseY,amp,r){var n=5,p=[],i;for(i=0;i<=n;i++)p.push([i/n*100,baseY+(r()*2-1)*amp]);
 var d="M0 100 L0 "+p[0][1].toFixed(1);
 for(i=1;i<=n;i++)d+=" Q "+p[i-1][0].toFixed(1)+" "+p[i-1][1].toFixed(1)+" "+((p[i-1][0]+p[i][0])/2).toFixed(1)+" "+((p[i-1][1]+p[i][1])/2).toFixed(1);
 d+=" L100 "+p[n][1].toFixed(1)+" L100 100 Z";return d;}
function scene(seed,cat){
 var h=hash(seed),r=rng(h),pal;
 if(cat&&CAT[cat])pal=PAL[CAT[cat].pal[h%CAT[cat].pal.length]];else pal=PAL[h%PAL.length];
 var sx=(18+r()*64).toFixed(0),sy=(22+r()*22).toFixed(0),sr=(11+r()*7).toFixed(1),id="g"+h;
 var a=hill(58,7,rng(hash(seed+"a"))),b=hill(70,9,rng(hash(seed+"b"))),c=hill(83,8,rng(hash(seed+"c")));
 return '<svg class="scene" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">'+
  '<defs><linearGradient id="'+id+'" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="'+pal.s1+'"/><stop offset="1" stop-color="'+pal.s2+'"/></linearGradient>'+
  '<radialGradient id="'+id+'s"><stop offset="0" stop-color="'+pal.sun+'" stop-opacity=".95"/><stop offset="1" stop-color="'+pal.sun+'" stop-opacity="0"/></radialGradient></defs>'+
  '<rect width="100" height="100" fill="url(#'+id+')"/><circle cx="'+sx+'" cy="'+sy+'" r="'+sr+'" fill="'+pal.sun+'"/>'+
  '<circle cx="'+sx+'" cy="'+sy+'" r="'+(sr*2.4).toFixed(1)+'" fill="url(#'+id+'s)"/>'+
  '<path d="'+a+'" fill="'+pal.h[0]+'" opacity=".92"/><path d="'+b+'" fill="'+pal.h[1]+'" opacity=".95"/><path d="'+c+'" fill="'+pal.h[2]+'"/></svg>';
}
/* duotone portrait avatar with initials */
function avatar(name){
 var h=hash(name),id="a"+h;
 var tone=[["#3a3632","#1d1b18"],["#3c3a40","#1c1b20"],["#39403c","#1b201d"],["#403a36","#1d1a17"]][h%4];
 var ini=name.split(/\s+/).map(function(w){return w[0];}).slice(0,2).join('').toUpperCase();
 return '<svg viewBox="0 0 100 120" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">'+
  '<defs><linearGradient id="'+id+'" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="'+tone[0]+'"/><stop offset="1" stop-color="'+tone[1]+'"/></linearGradient></defs>'+
  '<rect width="100" height="120" fill="url(#'+id+')"/><circle cx="50" cy="46" r="20" fill="rgba(255,255,255,.07)"/>'+
  '<path d="M22 120 q28 -34 56 0 Z" fill="rgba(255,255,255,.06)"/></svg>'+
  '<span class="ini">'+ini+'</span>';
}
function rel(h){if(h<1)return"Just now";if(h<24)return h+"h ago";var d=Math.round(h/24);return d===1?"Yesterday":d+" days ago";}
function tagHTML(cat){var c=catColor(cat);return '<span class="tag" style="color:'+c+'"><span class="dot" style="background:'+c+'"></span>'+cat+'</span>';}

/* =========================================================================
   CONTENT  (representative placeholder — wire to CMS / articlos for real data)
   ========================================================================= */
var FEAT={cat:"Cyber Scams",title:"Inside a Seized Scam Compound in Cambodia, the Machinery of Exploitation Comes Into View",dek:"A rare look behind the walls of the trafficking-fuelled fraud industry sweeping Southeast Asia.",read:9,when:"Today"};
var LATEST=[
 {cat:"Cyber Scams",title:"The Human Cost of Cyber Scam Operations in Southeast Asia",read:7,h:3},
 {cat:"Cyber Scams",title:"Cambodia's Crackdown on Scam Compounds: Progress and Pressure",read:6,h:9},
 {cat:"Social Innovation",title:"Kru Nam's Legacy: From Bamboo Huts to Generations of Change",read:5,h:26},
 {cat:"Ecocide",title:"Where Ecocide Is Happening Today, and Who It Harms",read:4,h:50}
];
var ARTS=[
 {cat:"Human Trafficking",title:"Understanding the Hidden Systems of Exploitation",dek:"How modern slavery operates in plain sight, and the signals that reveal it.",read:6,h:5,big:true},
 {cat:"Social Innovation",title:"Building Businesses That Empower Rather Than Exploit",dek:"Sustainable enterprise as a frontline tool against trafficking.",read:5,h:12},
 {cat:"Ecocide",title:"Confronting the Destruction of Our Shared Environment",dek:"Why environmental collapse and human exploitation are deeply linked.",read:7,h:20},
 {cat:"Cyber Scams",title:"The Human Cost of Cyber Scam Operations in Southeast Asia",dek:"Inside the trafficking pipeline feeding industrial-scale online fraud.",read:7,h:28},
 {cat:"Human Trafficking",title:"What Modern-Day Slavery Looks Like in 2026",dek:"The forms, the numbers, and the people behind them.",read:4,h:36},
 {cat:"Social Innovation",title:"Survivor-Led Enterprise: Dignity Through Work",dek:"Stories from the programs rebuilding lives and livelihoods.",read:5,h:44},
 {cat:"Ecocide",title:"How Ecocide Affects People as Well as Nature",dek:"The communities paying the price for large-scale destruction.",read:6,h:60}
];
var MOST=[
 {cat:"Cyber Scams",title:"Inside a Seized Scam Compound in Cambodia",read:9},
 {cat:"Human Trafficking",title:"What Modern-Day Slavery Looks Like in 2026",read:4},
 {cat:"Ecocide",title:"Confronting the Destruction of Our Shared Environment",read:7},
 {cat:"Social Innovation",title:"Kru Nam's Legacy: Generations of Change",read:5},
 {cat:"Cyber Scams",title:"Cambodia's Crackdown on Scam Compounds",read:6}
];
var SOCIAL=[
 {plat:"Instagram",t:"Kru Nam's Legacy",s:"From bamboo huts to generations of change"},
 {plat:"LinkedIn",t:"International Day of Democracy",s:"Why participation protects the vulnerable"},
 {plat:"TikTok",t:"September in Thailand",s:"A month on the frontlines"},
 {plat:"Facebook",t:"Charity, coupled with action",s:"David Batstone, Co-Founder"}
];
var FAQ=[
 {q:"What is Ecocide?",a:"Ecocide is the large-scale destruction of ecosystems that severely harms the environment and threatens the lives and livelihoods of people who depend on it. <a href='/explainer/?t=ecocide'>Learn more</a>"},
 {q:"What is Human Trafficking?",a:"Human trafficking is the use of force, fraud, or coercion to exploit people for labour or commercial gain. It is one of the fastest-growing criminal industries in the world. <a href='/explainer/?t=human-trafficking'>Learn more</a>"},
 {q:"What is Social Innovation?",a:"Social innovation means building sustainable businesses and models that empower communities rather than exploit them, creating alternatives that prevent trafficking before it starts. <a href='/explainer/?t=social-innovation'>Learn more</a>"}
];
var EXPLAINERS={
 "human-trafficking":{
   cat:"Human Trafficking", tag:"What it is & how we respond",
   title:"What is human trafficking?",
   direct:"Human trafficking is the exploitation of people through force, fraud, or coercion for labor, sex, or other services. It is a form of modern-day slavery that affects millions worldwide.",
   inDepth:["Human trafficking involves the recruitment, transportation, or harboring of individuals for the purpose of exploitation. Victims can be men, women, or children and are often coerced into work under inhumane conditions or exploited sexually.","Traffickers use threats, violence, deception, and manipulation to control their victims, hiding the abuse in plain sight."],
   solutions:["Provides support and rehabilitation for survivors.","Dismantles trafficking networks.","Creates economic stability in impoverished communities as prevention.","Addresses environmental destruction in at-risk communities.","Raises global awareness through education and advocacy."],
   summary:"Human trafficking is a modern form of slavery. Not For Sale combats it through rescue, survivor support, prevention, and economic development.",
   related:[
     {q:"What are the root causes of human trafficking?",a:"Poverty, environmental degradation, lack of education about traffickers, and systemic inequality often make individuals vulnerable."},
     {q:"Who is most at risk of being trafficked?",a:"People facing poverty, displacement, conflict, or social exclusion, especially women and children, are at heightened risk."},
     {q:"Is human trafficking happening in the U.S.?",a:"Yes. Trafficking occurs in every country, including the United States, across both labour and sex trafficking."}
   ]
 },
 "ecocide":{
   cat:"Ecocide", tag:"Protecting people & planet",
   title:"What is ecocide?",
   direct:"Ecocide is the large-scale destruction of ecosystems that severely harms the environment and threatens the lives and livelihoods of the people who depend on it.",
   inDepth:["Deforestation, pollution, and resource theft strip communities of the land, water, and stability they rely on. When livelihoods collapse, people are forced into desperate situations that traffickers exploit.","Environmental destruction and human exploitation are deeply linked, which is why we treat them as one fight."],
   solutions:["Protects ecosystems communities depend on.","Restores forests, soil, and biodiversity.","Builds sustainable, land-based livelihoods.","Reduces the displacement that fuels trafficking.","Advocates for ecocide to be recognised and prevented."],
   summary:"Ecocide destroys the environments people rely on and drives vulnerability. Not For Sale protects ecosystems to break cycles of exploitation.",
   related:[
     {q:"How does ecocide affect people as well as nature?",a:"When ecosystems collapse, communities lose food, income, and security, increasing the risk of displacement and exploitation."},
     {q:"Where is ecocide happening today?",a:"From deforestation to illegal mining and pollution, ecocide affects vulnerable communities across every continent."},
     {q:"Can ecocide be prevented?",a:"Yes, through restoration, sustainable livelihoods, accountability for harmful supply chains, and stronger legal protections."}
   ]
 },
 "social-innovation":{
   cat:"Social Innovation", tag:"Prevention through enterprise",
   title:"What is social innovation?",
   direct:"Social innovation means building sustainable businesses and models that empower communities rather than exploit them, creating alternatives that prevent trafficking before it starts.",
   inDepth:["Poverty and lack of opportunity fuel exploitation. Social innovation tackles that root cause by creating fair jobs, sustainable income, and community resilience.","These enterprises aren't just lifelines, they are engines of dignity and independence."],
   solutions:["Creates fair jobs and sustainable income.","Funds survivor reintegration through enterprise.","Strengthens community resilience.","Reduces the conditions traffickers exploit.","Proves business can be a force for good."],
   summary:"Social innovation builds the alternatives that make exploitation less likely, turning prevention into a self-sustaining model.",
   related:[
     {q:"How does social innovation fight human trafficking?",a:"By creating economic opportunity and stability, it removes the desperation that traffickers prey on."},
     {q:"Why is social innovation important for sustainable change?",a:"It addresses root causes rather than symptoms, creating change that lasts beyond any single intervention."},
     {q:"What does a social enterprise look like?",a:"From restaurants to consumer brands, these are real businesses whose profits and practices serve their communities."}
   ]
 }
};
var FAQLIST=[
 {cat:"About & Mission",q:"What is Not For Sale's mission?",a:"Globally, there are 45.8 million people living in slavery. Not For Sale is a global NGO leading innovative solutions that fight human trafficking and environmental exploitation, with survivor support and alleviation programs on five continents. We build social enterprises designed to make social impact profitable. Together with our global community of freedom fighters, we are striving for a world where no one is for sale. <a href='/about/'>Learn more about our work</a>."},
 {cat:"Reporting",q:"Can I report suspected human trafficking to Not For Sale?",a:"Not For Sale does not undertake rescues or respond to individual reports of human trafficking, as this is a matter for law enforcement. To report suspected human trafficking, call the National Human Trafficking Hotline at <a href='tel:+18883737888'>1-888-373-7888</a>. If you are in danger, call <a href='tel:911'>911</a>."},
 {cat:"About & Mission",q:"How can I contact someone at Not For Sale?",a:"You can <a href='/contact/'>reach out to us here</a>. While we value your input, we receive hundreds of emails a day and our capacity to respond to individual queries is limited. We will get back to you as soon as possible."},
 {cat:"Get Involved",q:"How can I collaborate with Not For Sale?",a:"Email <a href='mailto:team@wearenotforsale.org'>team@wearenotforsale.org</a> with further details. We will respond if we are able to help or collaborate in any way."},
 {cat:"Fundraising",q:"How can I get involved with Not For Sale's fundraising?",a:"The best way to get involved is to donate or become a fundraiser. You can also support us by shopping at the Not For Sale online store, and with everyday purchases through the AmazonSmile programme."},
 {cat:"Donations",q:"How can I donate to Not For Sale?",a:"There are many ways to donate, make as many one-off payments as you like, or join one of our monthly giving communities. Several payment methods are available so you can choose the one that suits you best."},
 {cat:"Donations",q:"Can I donate through Venmo?",a:"Yes. At the bottom of the donation page, select Venmo. It opens in a new window; select Review Order to return to the donation page, then confirm. Note: Venmo is currently only available on mobile, use Safari on iPhone and Chrome on Android."},
 {cat:"Fundraising",q:"How do I become a fundraiser for Not For Sale?",a:"Whether solo or as a team, you can set up your own personalised fundraiser on our website, or on our Facebook page. We also have a fundraising pack to help you get started."},
 {cat:"Donations",q:"How can I update my donation and card details?",a:"<a href='"+(CFG.donorLogin||"https://pro.gofundme.com/sso")+"'>Log in to your donor account</a>, open the recurring donations section, click edit donation under the donation you want to manage, and update your card details or recurring amount. First time logging in? Use forgot password to set one over email."},
 {cat:"Fundraising",q:"How do I shop with AmazonSmile?",a:"Every time you shop with AmazonSmile, Not For Sale receives 0.5% of eligible purchases at no extra cost to you. Select Not For Sale as your charity of choice. However you give, 100% of donations go directly to serve people vulnerable to exploitation around the world."},
 {cat:"Fundraising",q:"Do you provide any tools to help with fundraising?",a:"Yes. A fundraising pack with ideas and information to maximise your results; a digital toolkit with images and social post templates; and a platform to create fundraising teams and pages."},
 {cat:"Donations",q:"Do you accept mail donations?",a:"Yes. To donate by check, make it out to Not For Sale Fund and send it to: Not For Sale, 1930 Village Center Circle #3-19535, Las Vegas, NV 89134, USA."},
 {cat:"Donations",q:"Can I donate my stocks to Not For Sale?",a:"Yes. We have a helpful guide on how to generously transfer your stocks to Not For Sale."},
 {cat:"Donations",q:"Can my employer match my donation?",a:"Yes, depending on your employer. Use our employer matching search tool to see if your company will match your donation and to access the forms and instructions you need."},
 {cat:"About & Mission",q:"Are you involved in any US-based project work?",a:"Yes. One of our newest enterprises is Krunam, a California start-up. In 2020 alone, over 60 million CSAM images or videos were reported by authorities globally. Krunam identifies and classifies previously unknown CSAM at scale, protecting online communities and millions of children, and donates a percentage of revenue back to Not For Sale."},
 {cat:"Updates",q:"How can I keep up-to-date with Not For Sale?",a:"Sign up to our e-newsletter and follow us on <a href='https://www.facebook.com/notforsale'>Facebook</a> and <a href='https://www.instagram.com/nfs/'>Instagram</a>."}
];
var COUNTRIES=[
 ["Argentina","Americas"],["Bolivia","Americas"],["Brazil","Americas"],["Canada","Americas"],
 ["Colombia","Americas"],["Peru","Americas"],["United States","Americas"],
 ["Cameroon","Africa"],["DR Congo","Africa"],["Guinea","Africa"],["Madagascar","Africa"],
 ["Mozambique","Africa"],["Rwanda","Africa"],["Senegal","Africa"],["South Africa","Africa"],
 ["Tanzania","Africa"],["Uganda","Africa"],
 ["Italy","Europe"],["Netherlands","Europe"],["Sweden","Europe"],["United Kingdom","Europe"],
 ["Australia","Asia-Pacific"],["Japan","Asia-Pacific"],["Laos","Asia-Pacific"],
 ["Myanmar","Asia-Pacific"],["Thailand","Asia-Pacific"],["Vietnam","Asia-Pacific"]
].map(function(r){return {name:r[0],region:r[1],slug:slug(r[0])};});
var WORK=["Netherlands","Vietnam","South Africa","Mozambique","Thailand","Laos","Myanmar","Uganda","DR Congo","Peru","United States"];
var FOCUS={Americas:["Survivor care","Prevention","Reforestation"],Africa:["Reintegration","Education","Agroforestry"],Europe:["Aftercare","Vocational training","Advocacy"],"Asia-Pacific":["Rescue","Safe homes","Education"]};
var PROJECT_SINCE={Americas:"2014",Africa:"2011",Europe:"2013",
"Asia-Pacific":"2012"};
var FOUNDERS=[
 {name:"David Batstone",role:"President & Co-Founder",bio:["David is the co-founder and president of Not For Sale, a global organisation working to end human trafficking and environmental exploitation through systemic solutions and social enterprise. He is also co-founder and managing partner of Just Business, an international investment group that incubates mission-driven companies including REBBL and Dignita.",
 "He is Professor Emeritus at the University of San Francisco, an author of five books, a recipient of two national journalism awards, and a recipient of the Peace Award from the United Nations Women for Peace Association for his work advancing human dignity and justice."]},
 {name:"Mark Wexler",role:"CEO & Co-Founder",bio:["Mark is the co-founder and CEO of Not For Sale, working to end human trafficking and environmental degradation by addressing root causes and empowering survivors through systemic solutions. He is also co-founder and partner of Just Business.",
 "Mark is currently helping launch M2i Global, a minerals and metals company building a U.S. minerals reserve while deploying policy and technology solutions to reduce the risk of forced labour and ecocide in global supply chains. He is a Visiting Research Fellow at King's College London and a widely published author and speaker on ethical business and supply-chain accountability."]}
];
var DIRECTORS=[
 {name:"Toos Heemskerk",role:"Country Director",loc:"Netherlands"},
 {name:"Michael Brosowski",role:"Co-Country Director",loc:"Vietnam"},
 {name:"Tom Hewitt MBE",role:"Country Director",loc:"South Africa & Mozambique"},
 {name:"Kru Nam",role:"Country Director",loc:"Thailand, Laos & Myanmar"},
 {name:"Ntakamaze (TK) Nziyonvira",role:"Country Director",loc:"Uganda & DR Congo"}
];
var PARTNERS=[
 {name:"AllSaints",sub:"Fashion",sector:"Retail / Fashion",since:"2014",blurb:"A decade-long collaboration supporting ethical fashion, community programs, and the fight against human trafficking."},
 {name:"M2i Global",sub:"Minerals · Metals Initiatives",sector:"Minerals & Metals",since:"2024",blurb:"Building responsible mineral supply chains while reducing the risk of forced labour and ecocide."},
 {name:"Regenerate",sub:"Clean Technology",sector:"Technology",since:"2022",blurb:"Advancing clean energy, battery recycling, and sustainable solutions that reduce environmental harm."},
 {name:"ABTC",sub:"American Battery",sector:"Clean Energy",since:"2023",blurb:"Supporting a circular battery economy and ethical resource recovery."},
 {name:"Insured Nomads",sub:"Travel & Insurance",sector:"Insurance",since:"2021",blurb:"Protecting people on the move and funding frontline anti-trafficking work."},
 {name:"Dignitá",sub:"eat well, do good",sector:"Social Enterprise",since:"2016",blurb:"Restaurants and training programs that help survivors rebuild lives and prevent trafficking."},
 {name:"OHO",sub:"Lifestyle",sector:"Consumer",since:"2020",blurb:"A purpose-driven brand channelling sales into survivor support."},
 {name:"Alex and Ani",sub:"Jewellery",sector:"Retail",since:"2015",blurb:"A purpose-driven charm partnership raising awareness and funds to fight human trafficking."},
 {name:"Boll & Branch",sub:"Home",sector:"Retail / Home",since:"2019",blurb:"Advancing Fair Trade supply chains and global efforts to combat human trafficking."}
];

/* =========================================================================
   SHARED CHROME
   ========================================================================= */
var NAV=[
 {label:"Home",href:"/",page:"home"},
 {label:"Our Projects",href:"/projects/",page:"projects"},
 {label:"Causes",group:"causes",children:[
   {label:"Human Trafficking",href:"/explainer/?t=human-trafficking",sub:"What it is & how we respond"},
   {label:"Social Innovation",href:"/explainer/?t=social-innovation",sub:"Prevention through enterprise"},
   {label:"Ecocide",href:"/explainer/?t=ecocide",sub:"Protecting people & planet"},
   {divider:true},
   {label:"FAQ",href:"/faq/",sub:"Answers to common questions"}
 ]},
 {label:"About",group:"about",children:[
   {label:"About Us",href:"/about/",sub:"Our story & mission"},
   {label:"Our Team",href:"/team/",sub:"Founders & directors"},
   {label:"Our Partners",href:"/partners/",sub:"Companies fighting with us"}
 ]},
 {label:"News",href:"/news/",page:"news"}
];
var GROUP_PAGES={causes:["explainer","faq"],about:["about","team","partners"]};
function injectHeader(page){
 var center=NAV.map(function(n){
   if(n.children){
     var active=(GROUP_PAGES[n.group]||[]).indexOf(page)>=0;
     var dd=n.children.map(function(c){return c.divider?'<div class="divider"></div>':'<a href="'+c.href+'"><span class="lk">'+c.label+'</span>'+(c.sub?'<small>'+c.sub+'</small>':'')+'</a>';}).join('');
     return '<div class="nav-item"><button class="nav-trigger'+(active?' active':'')+'" aria-haspopup="true">'+n.label+'<span class="car"></span></button><div class="dropdown">'+dd+'</div></div>';
   }
   return '<div class="nav-item"><a class="nav-link'+(n.page===page?' active':'')+'" href="'+n.href+'">'+n.label+'</a></div>';
 }).join('');
 var mob=NAV.map(function(n){
   if(n.children){return '<div class="mm-group">'+n.label+'</div>'+n.children.filter(function(c){return !c.divider;}).map(function(c){return '<a class="mm-sub" href="'+c.href+'">'+c.label+'</a>';}).join('');}
   return '<a class="mm-link'+(n.page===page?' active':'')+'" href="'+n.href+'">'+n.label+'</a>';
 }).join('');
 var html='<div class="wrap nav">'+
   '<div class="left"><a class="brand" href="/">'+BRAND+'</a></div>'+
   '<div class="center"><nav class="nav-links">'+center+'</nav></div>'+
   '<div class="right"><a class="btn btn-ink" href="#">Donate</a>'+
   '<button class="burger" id="burger" aria-label="Open menu" aria-expanded="false"><span></span><span></span><span></span></button></div>'+
   '</div>'+
   '<div class="mm-scrim" id="mmScrim"></div>'+
   '<aside class="mobile-menu" id="mobileMenu" aria-label="Menu">'+
     '<div class="mm-top"><span class="brand">'+BRAND+'</span>'+
       '<button class="mm-close" id="mmClose" aria-label="Close menu"><span></span><span></span></button></div>'+
     '<nav class="mm-nav">'+mob+'</nav>'+
     '<a class="btn btn-orange mm-donate" href="#">Donate</a>'+
   '</aside>';
 var h=document.getElementById('site-header'); if(h){var el=document.createElement('header');el.id='hdr';el.innerHTML=html;h.replaceWith(el);}
}
function injectNewsletter(){
 var n=document.getElementById('site-newsletter'); if(!n)return;
 n.outerHTML='<div class="nl"><div class="wrap in">'+
  '<span class="flame" style="display:inline-grid;width:44px;height:44px">'+FLAME+'</span>'+
  '<h2>Sign Up to Our Newsletter</h2>'+
  '<p>Join our movement and get the latest updates, stories, and ways to take action, straight to your inbox.</p>'+
  '<div class="row"><form class="nfs-protected" style="display:flex;gap:8px;width:100%" '+(MAILCHIMP_ACTION?('action="'+MAILCHIMP_ACTION+'" method="post" target="_blank"'):'onsubmit="return false"')+'><input name="EMAIL" type="email" required placeholder="Email Address *" aria-label="Email"><button type="submit">Sign Up</button></form></div></div></div>';
}
function injectFooter(){
 var f=document.getElementById('site-footer'); if(!f)return;
 f.outerHTML='<footer class="site"><div class="wrap">'+
  '<div class="fcols"><div><div class="fbrand"><span class="flame">'+FLAME+'</span><span class="name">Not For Sale</span></div>'+
  '<p class="fmute">A global movement fighting human trafficking through prevention, rescue, and reintegration since 2006.</p></div>'+
  '<div><h5>About</h5><a href="/about/">About Us</a><a href="/team/">Our Team</a><a href="/faq/">FAQ</a><a href="#">Donate</a></div>'+
  '<div><h5>Causes</h5><a href="/explainer/?t=human-trafficking">Human Trafficking</a><a href="/explainer/?t=social-innovation">Social Innovation</a><a href="/explainer/?t=ecocide">Ecocide</a><a href="/news/">News</a></div>'+
  '<div><h5>Follow Us</h5><a href="#">Instagram</a><a href="#">LinkedIn</a><a href="#">TikTok</a><a href="#">Facebook</a></div></div>'+
  '<div class="fbot"><div>© Not For Sale 2026. All rights reserved.</div><div class="fmark">WE ARE NOT FOR SALE</div></div></div></footer>';
}

/* =========================================================================
   PAGE RENDERERS
   ========================================================================= */
function el(id){return document.getElementById(id);}
function renderHome(){
 var feat=el('feat'); if(feat){feat.href='/news/';feat.innerHTML=
  '<div class="ph">'+scene(FEAT.title,FEAT.cat)+'</div>'+
  '<span class="live"><span class="pulse"></span>Investigation · '+FEAT.when+'</span>'+
  '<div class="txt"><div class="ftag">'+tagHTML(FEAT.cat)+'</div><h1>'+FEAT.title+'</h1>'+
  '<p class="dek">'+FEAT.dek+'</p><div class="fmeta">'+FEAT.read+' min read · '+FEAT.when+'</div></div>';}
 var ll=el('latestList'); if(ll)ll.innerHTML=LATEST.map(function(a){return '<a class="li" href="/news/"><div class="th">'+scene(a.title,a.cat)+'</div><div class="c"><div class="t">'+a.title+'</div><div class="m"><b>'+rel(a.h)+'</b> · '+a.read+' min</div></div></a>';}).join('');
 // frontlines filter + feed
 var active="All";
 var fbox=el('filters');
 if(fbox){["All"].concat(Object.keys(CAT).filter(function(c){return c!=="Social Enterprise";})).forEach(function(c){
   var b=document.createElement('button');b.className='chip'+(c==="All"?' on':'');b.textContent=c;
   b.onclick=function(){active=c;[].forEach.call(fbox.children,function(x){x.classList.toggle('on',x.textContent===c);});feed();};fbox.appendChild(b);});}
 function feed(){var list=active==="All"?ARTS:ARTS.filter(function(a){return a.cat===active;});var f=el('feed');if(!f)return;f.innerHTML='';
   list.forEach(function(a){var e=document.createElement('a');e.className='art'+(a.big&&active==="All"?' big':'');e.href='/news/';
    e.innerHTML='<div class="ph">'+scene(a.title,a.cat)+(a.h<8?'<span class="new">New</span>':'')+'</div>'+
     '<div class="b">'+tagHTML(a.cat)+'<div class="t">'+a.title+'</div><div class="dek">'+a.dek+'</div>'+
     '<div class="am"><span>'+rel(a.h)+'</span><span>'+a.read+' min read →</span></div></div>';f.appendChild(e);});}
 feed();
 var mr=el('mostRead'); if(mr)mr.innerHTML=MOST.map(function(a,i){return '<a class="mr" href="/news/"><div class="num">'+("0"+(i+1)).slice(-2)+'</div><div><div class="t">'+a.title+'</div><div class="m">'+a.cat+' · '+a.read+' min read</div></div></a>';}).join('');
 var soc=el('social'); if(soc)soc.innerHTML=SOCIAL.map(function(s){return '<div class="scard"><div class="ph">'+scene(s.t+s.plat)+'<div class="cap"><div class="t">'+s.t+'</div><div class="s">'+s.s+'</div></div></div><div class="pl"><span>'+s.plat+'</span></div></div>';}).join('');
 var fv=el('founderVid'); if(fv)fv.insertAdjacentHTML('afterbegin',scene("founder-a-new-chapter","Human Trafficking"));
 buildFAQ(el('faq'),FAQ,'+');
}
function renderProjects(){
 var active="All";var regions=["All"];COUNTRIES.forEach(function(d){if(regions.indexOf(d.region)<0)regions.push(d.region);});
 var fbox=el('pfilters');
 regions.forEach(function(r){var b=document.createElement('button');b.className='chip'+(r==="All"?' on':'');b.textContent=r;
   b.onclick=function(){active=r;[].forEach.call(fbox.children,function(x){x.classList.toggle('on',x.textContent===r);});draw();};fbox.appendChild(b);});
 var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target);}});},{threshold:.1});
 function draw(){var list=active==="All"?COUNTRIES:COUNTRIES.filter(function(d){return d.region===active;});
   var g=el('pgrid');g.innerHTML='';el('pcount').textContent=list.length+' programs';
   list.forEach(function(d,i){var f=FLAGS[d.slug]?'<img class="flag" src="'+FLAGS[d.slug]+'" alt="">':'';
     var a=document.createElement('a');a.className='pcard';a.href='/project/?c='+d.slug;a.style.transitionDelay=((i%8)*45)+'ms';
     a.innerHTML='<div class="ph">'+scene(d.name)+f+'</div><div class="meta"><div class="reg">'+d.region+'</div><div class="name">'+d.name+'</div><span class="go">View projects →</span></div>';
     g.appendChild(a);io.observe(a);});}
 draw();
}
function renderAbout(){
 var v=el('founderVid'); if(v)v.insertAdjacentHTML('afterbegin',scene("about-origin","Human Trafficking"));
 var names=["Human Trafficking","Social Enterprise","Ecocide"];
 document.querySelectorAll('.acard .ph').forEach(function(p,i){p.insertAdjacentHTML('afterbegin',scene("approach-"+names[i],names[i]));});
 var fg=el('flagGrid'); if(fg)fg.innerHTML=WORK.map(function(n){var s=slug(n);var f=FLAGS[s]?'<img src="'+FLAGS[s]+'" alt="">':'';return '<a class="fchip" href="/projects/">'+f+'<span>'+n+'</span></a>';}).join('');
}
function renderTeam(){
 var f=el('founders'); if(f)f.innerHTML=FOUNDERS.map(function(p){return '<div class="founder-row"><div class="avatar">'+avatar(p.name)+'</div>'+
   '<div class="bio"><div class="role">'+p.role+'</div><h3>'+p.name+'</h3>'+p.bio.map(function(t){return '<p>'+t+'</p>';}).join('')+'</div></div>';}).join('');
 var d=el('directors'); if(d)d.innerHTML=DIRECTORS.map(function(p){return '<div class="dcard"><div class="avatar">'+avatar(p.name)+'</div>'+
   '<div class="role">'+p.role+'</div><h3>'+p.name+'</h3><div class="loc"><b>'+p.loc+'</b></div></div>';}).join('');
}
function renderPartners(){
 var g=el('logoGrid'); if(g)g.innerHTML=PARTNERS.map(function(p){return '<a class="logo" href="/partner/?p='+slug(p.name)+'">'+scene("partner-"+p.name)+'<div class="wm">'+p.name+(p.sub?'<small>'+p.sub+'</small>':'')+'</div></a>';}).join('');
}
function getParam(k){try{return new URLSearchParams(location.search).get(k);}catch(e){return null;}}
function renderProject(){
 var sl=getParam('c')||'thailand';
 var d=COUNTRIES.filter(function(c){return c.slug===sl;})[0]||COUNTRIES.filter(function(c){return c.slug==='thailand';})[0];
 var ph=el('dheroPh'); if(ph)ph.innerHTML=scene(d.name);
 var fr=el('pjFlag'); if(fr&&FLAGS[d.slug])fr.innerHTML='<img src="'+FLAGS[d.slug]+'" alt="">';
 var k=el('pjKicker'); if(k)k.innerHTML='<span class="dash"></span>'+d.region+' · Programme';
 var t=el('pjTitle'); if(t)t.textContent=d.name;
 if(document.title)document.title=d.name+' — Not For Sale';
 var focus=FOCUS[d.region]||[];
 var ft=el('pjFocus'); if(ft)ft.innerHTML=focus.map(function(f){return '<span class="tag"><span class="dot"></span>'+f+'</span>';}).join('');
 var fbR=el('fbRegion'); if(fbR)fbR.textContent=d.region;
 var fbF=el('fbFocus'); if(fbF)fbF.textContent=focus.join(', ');
 var fbS=el('fbSince'); if(fbS)fbS.textContent=PROJECT_SINCE[d.region]||'2012';
 var rn=el('pjRegionName'); if(rn)rn.textContent=d.region;
 var fig=el('pjFig'); if(fig)fig.insertAdjacentHTML('afterbegin',scene(d.name+'-field'));
 var rel=el('pjRelated');
 if(rel){var more=COUNTRIES.filter(function(c){return c.region===d.region&&c.slug!==d.slug;}).slice(0,4);
   rel.innerHTML=more.map(function(c){var f=FLAGS[c.slug]?'<img class="flag" src="'+FLAGS[c.slug]+'" alt="">':'';
     return '<a class="pcard in" href="/project/?c='+c.slug+'"><div class="ph">'+scene(c.name)+f+'</div><div class="meta"><div class="reg">'+c.region+'</div><div class="name">'+c.name+'</div><span class="go">View project →</span></div></a>';}).join('');}
}
function renderPartner(){
 var sl=getParam('p')||'allsaints';
 var d=PARTNERS.filter(function(p){return slug(p.name)===sl;})[0]||PARTNERS[0];
 var ph=el('dheroPh'); if(ph)ph.innerHTML=scene("partner-"+d.name);
 var t=el('pnTitle'); if(t)t.innerHTML=d.name+(d.sub?'<small>'+d.sub+'</small>':'');
 if(document.title)document.title=d.name+' — Not For Sale Partner';
 var l=el('pnLede'); if(l)l.textContent=d.blurb;
 var fbSec=el('fbSector'); if(fbSec)fbSec.textContent=d.sector;
 var fbSince=el('fbPartnerSince'); if(fbSince)fbSince.textContent=d.since;
 var rel=el('pnRelated');
 if(rel){var more=PARTNERS.filter(function(p){return slug(p.name)!==sl;}).slice(0,3);
   rel.innerHTML=more.map(function(p){return '<a class="logo" href="/partner/?p='+slug(p.name)+'">'+scene("partner-"+p.name)+'<div class="wm">'+p.name+(p.sub?'<small>'+p.sub+'</small>':'')+'</div></a>';}).join('');}
}
function bindAccordion(host){
 host.querySelectorAll('.qa').forEach(function(qa){var a=qa.querySelector('.a');
   if(qa.classList.contains('open'))a.style.maxHeight=a.scrollHeight+'px';
   qa.querySelector('.q').onclick=function(){var open=qa.classList.contains('open');
     host.querySelectorAll('.qa').forEach(function(o){o.classList.remove('open');o.querySelector('.a').style.maxHeight=null;});
     if(!open){qa.classList.add('open');a.style.maxHeight=a.scrollHeight+'px';}};});
}
function renderExplainer(){
 var t=getParam('t')||'human-trafficking';
 var d=EXPLAINERS[t]||EXPLAINERS['human-trafficking'];
 var ACC={"human-trafficking":"#c46f49","social-innovation":"#4f8e92","ecocide":"#5b7747"};
 var root=el('exRoot'); if(root)root.style.setProperty('--accent',ACC[t]||'#F5821F');
 if(document.title)document.title=d.title+' — Not For Sale';
 var k=el('exKicker'); if(k)k.innerHTML='<span class="dash"></span>'+d.cat;
 var h=el('exTitle'); if(h)h.textContent=d.title;
 var da=el('exDirect'); if(da)da.textContent=d.direct;
 var cov=el('exCover'); if(cov)cov.insertAdjacentHTML('afterbegin',scene(d.title,d.cat));
 var idp=el('exInDepth'); if(idp)idp.innerHTML=d.inDepth.map(function(p){return '<p>'+p+'</p>';}).join('');
 var st=el('exSteps'); if(st)st.innerHTML=d.solutions.map(function(s,i){return '<div class="ex-step"><div class="n">'+("0"+(i+1)).slice(-2)+'</div><p>'+s+'</p></div>';}).join('');
 var sm=el('exSummary'); if(sm)sm.innerHTML='<p>'+d.summary+'</p>';
 buildFAQ(el('exRelated'),d.related,'+');
 var more=el('exMore');
 if(more){var keys=Object.keys(EXPLAINERS).filter(function(x){return x!==t;});
   more.innerHTML=keys.map(function(x){var e=EXPLAINERS[x];return '<a class="ex-mc" href="/explainer/?t='+x+'">'+scene(e.title,e.cat)+'<div class="t">'+e.cat+'<small>'+e.tag+'</small></div></a>';}).join('');}
}
function renderFaq(){
 var cats=["All"]; FAQLIST.forEach(function(f){if(cats.indexOf(f.cat)<0)cats.push(f.cat);});
 var state={cat:"All",q:""};
 function cnt(c){return c==="All"?FAQLIST.length:FAQLIST.filter(function(f){return f.cat===c;}).length;}
 var nav=el('catNav');
 if(nav){nav.innerHTML=cats.map(function(c){return '<button data-c="'+c+'" class="'+(c==="All"?'on':'')+'">'+c+'<span class="ct">'+cnt(c)+'</span></button>';}).join('');
   nav.querySelectorAll('button').forEach(function(b){b.onclick=function(){state.cat=b.dataset.c;nav.querySelectorAll('button').forEach(function(x){x.classList.toggle('on',x===b);});draw();};});}
 var search=el('faqSearch'); if(search)search.addEventListener('input',function(){state.q=this.value.toLowerCase().trim();draw();});
 function item(f){return '<div class="qa"><div class="q">'+f.q+'<span class="ic">+</span></div><div class="a"><p>'+f.a+'</p></div></div>';}
 function draw(){
   var list=FAQLIST.filter(function(f){return (state.cat==="All"||f.cat===state.cat)&&(!state.q||(f.q+' '+f.a).toLowerCase().indexOf(state.q)>=0);});
   var host=el('faqList'); if(!host)return;
   if(!list.length){host.innerHTML='<div class="help-empty">No questions match “'+state.q+'”. Try a different search.</div>';return;}
   var html='';
   if(state.cat==="All"&&!state.q){
     cats.slice(1).forEach(function(c){var items=list.filter(function(f){return f.cat===c;});if(items.length)html+='<div class="grouplabel">'+c+'</div>'+items.map(item).join('');});
   } else { html=list.map(item).join(''); }
   host.innerHTML=html; bindAccordion(host);
 }
 draw();
}
function renderNews(){
 var NEWS=[FEAT].concat(LATEST).concat(ARTS);
 var active="All";
 var fbox=el('newsFilters');
 if(fbox){["All"].concat(Object.keys(CAT).filter(function(c){return c!=="Social Enterprise";})).forEach(function(c){
   var b=document.createElement('button');b.className='chip'+(c==="All"?' on':'');b.textContent=c;
   b.onclick=function(){active=c;[].forEach.call(fbox.children,function(x){x.classList.toggle('on',x.textContent===c);});draw();};fbox.appendChild(b);});}
 function draw(){var list=active==="All"?NEWS:NEWS.filter(function(a){return a.cat===active;});
   var g=el('newsGrid');if(!g)return;g.innerHTML='';var cnt=el('newsCount');if(cnt)cnt.textContent=list.length+' stories';
   list.forEach(function(a){var g2=document.createElement('a');g2.className='art';g2.href='/news/';
     g2.innerHTML='<div class="ph">'+scene(a.title,a.cat)+(a.h<8?'<span class="new">New</span>':'')+'</div>'+
      '<div class="b">'+tagHTML(a.cat)+'<div class="t">'+a.title+'</div>'+(a.dek?'<div class="dek">'+a.dek+'</div>':'')+
      '<div class="am"><span>'+(a.when||rel(a.h))+'</span><span>'+a.read+' min read →</span></div></div>';g.appendChild(g2);});}
 draw();
}
function renderBlog(){
 var bav=el('blogAuthorAv'); if(bav)bav.insertAdjacentHTML('afterbegin',avatar("Field Report"));
 var cov=el('postCover'); if(cov)cov.insertAdjacentHTML('afterbegin',scene(FEAT.title,FEAT.cat));
 document.querySelectorAll('.inlinefig').forEach(function(fig,i){fig.insertAdjacentHTML('afterbegin',scene("inline-"+i,"Cyber Scams"));});
 var ab=el('authorAv'); if(ab)ab.insertAdjacentHTML('afterbegin',avatar("Field Report"));
 var rel2=el('related'); if(rel2)rel2.innerHTML=ARTS.slice(0,3).map(function(a){return '<a class="art" href="/news/"><div class="ph">'+scene(a.title,a.cat)+'</div><div class="b">'+tagHTML(a.cat)+'<div class="t">'+a.title+'</div><div class="am"><span>'+a.read+' min read</span><span>→</span></div></div></a>';}).join('');
}

/* generic FAQ builder (light) */
function buildFAQ(host,items,icon){ if(!host)return;
 host.innerHTML=items.map(function(f,i){return '<div class="qa'+(i===0?' open':'')+'"><div class="q">'+f.q+'<span class="ic">'+icon+'</span></div><div class="a"><p>'+f.a+'</p></div></div>';}).join('');
 host.querySelectorAll('.qa').forEach(function(qa){var a=qa.querySelector('.a');if(qa.classList.contains('open'))a.style.maxHeight=a.scrollHeight+'px';
   qa.querySelector('.q').onclick=function(){var open=qa.classList.contains('open');
     host.querySelectorAll('.qa').forEach(function(o){o.classList.remove('open');o.querySelector('.a').style.maxHeight=null;});
     if(!open){qa.classList.add('open');a.style.maxHeight=a.scrollHeight+'px';}};});
}

/* =========================================================================
   UNIVERSAL BEHAVIOURS
   ========================================================================= */
function countUp(elm,dur){var to=+elm.dataset.to,suf=elm.dataset.suffix||'',cm=elm.dataset.comma;
 var fmt=function(v){return cm?Math.round(v).toLocaleString('en-US'):Math.round(v);};var st=performance.now();
 (function s(n){var t=Math.min(1,(n-st)/dur),e=1-Math.pow(1-t,3);elm.textContent=fmt(to*e)+(t>.5?suf:'');if(t<1)requestAnimationFrame(s);else elm.textContent=fmt(to)+suf;})(st);}

function renderContact(){
 var root=el('contactRoot'); if(!root)return;
 var s=(CFG.social||{}), email=CFG.contactEmail||'team@wearenotforsale.org', addr=CFG.address||'', rc=CFG.recaptcha||{};
 var q=(location.search.match(/[?&]nfs=([a-z]+)/)||[])[1];
 var notes={sent:['ok','Thank you. Your message has been sent.'],error:['err','Something went wrong. Please try again or email us directly.'],invalid:['err','Please complete all fields with a valid email.'],captcha:['err','The captcha check failed. Please try again.']};
 var banner=notes[q]?'<div class="cform-note '+notes[q][0]+'">'+notes[q][1]+'</div>':'';
 var soc=[];
 if(s.ig)soc.push('<a href="'+s.ig+'">Instagram</a>'); if(s.fb)soc.push('<a href="'+s.fb+'">Facebook</a>');
 if(s.li)soc.push('<a href="'+s.li+'">LinkedIn</a>'); if(s.tt)soc.push('<a href="'+s.tt+'">TikTok</a>');
 var rcField = (rc.enabled&&rc.site&&rc.version!=='v3') ? '<div class="g-recaptcha" data-sitekey="'+rc.site+'"></div>' : '';
 var hotlines=[['United States','National Human Trafficking Hotline','tel:+18883737888','1-888-373-7888'],['United States','Emergency','tel:911','911']];
 var hot=hotlines.map(function(h){return '<div class="hot"><div class="c">'+h[0]+'</div><div class="n">'+h[1]+'</div><a href="'+h[2]+'">'+h[3]+'</a></div>';}).join('');
 root.innerHTML=
  '<section class="pagehead"><div class="wrap">'+
    '<div class="kicker fade"><span class="dash"></span>Get in touch</div>'+
    '<h1 class="fade">Contact <em>Us</em></h1>'+
    '<p class="lede fade">Questions, partnership ideas, or media enquiries. We read every message, and reply when we can.</p>'+
  '</div></section>'+
  '<div class="wrap"><div class="detail">'+
    '<div class="main">'+banner+
      '<form class="cform nfs-protected fade" action="'+(CFG.postUrl||'')+'" method="post">'+
        '<input type="hidden" name="action" value="nfs_contact">'+
        '<input type="hidden" name="_wpnonce" value="'+(CFG.contactNonce||'')+'">'+
        '<input type="text" name="nfs_hp" tabindex="-1" autocomplete="off" style="position:absolute;left:-9999px" aria-hidden="true">'+
        '<label>Name<input type="text" name="nfs_name" required></label>'+
        '<label>Email<input type="email" name="nfs_email" required></label>'+
        '<label>Message<textarea name="nfs_message" rows="6" required></textarea></label>'+
        rcField+
        '<button class="btn btn-orange" type="submit">Send message</button>'+
      '</form>'+
    '</div>'+
    '<aside class="factbox fade"><h4>Reach the team</h4>'+
      '<div class="frow"><span class="k">Email</span><span class="v"><a href="mailto:'+email+'">'+email+'</a></span></div>'+
      (addr?'<div class="frow"><span class="k">Address</span><span class="v">'+addr+'</span></div>':'')+
      (soc.length?'<div class="frow"><span class="k">Social</span><span class="v">'+soc.join(' &middot; ')+'</span></div>':'')+
    '</aside>'+
  '</div></div>'+
  '<section class="sec"><div class="wrap"><div class="sec-h fade"><div><h2>Need help now?</h2><p>Not For Sale does not handle rescues. To report trafficking, contact your local authorities or these lines.</p></div></div>'+
    '<div class="hotgrid fade">'+hot+'</div>'+
  '</div></section>';
}

function init(){
 var page=document.body.getAttribute('data-page');
 injectHeader(page); injectNewsletter(); injectFooter();
 document.querySelectorAll('.flame').forEach(function(fl){if(!fl.innerHTML.trim())fl.innerHTML=FLAME;});
 // mobile menu
 var burger=el('burger'),menu=el('mobileMenu'),scrim=el('mmScrim'),closeb=el('mmClose');
 function setMenu(o){if(menu)menu.classList.toggle('open',o);if(scrim)scrim.classList.toggle('open',o);if(burger){burger.classList.toggle('x',o);burger.setAttribute('aria-expanded',o);}document.body.classList.toggle('lock',o);}
 if(burger&&menu){
   burger.addEventListener('click',function(){setMenu(!menu.classList.contains('open'));});
   if(closeb)closeb.addEventListener('click',function(){setMenu(false);});
   if(scrim)scrim.addEventListener('click',function(){setMenu(false);});
   menu.querySelectorAll('a').forEach(function(a){a.addEventListener('click',function(){setMenu(false);});});
 }
 if(page==='home')renderHome();
 else if(page==='projects')renderProjects();
 else if(page==='about')renderAbout();
 else if(page==='team')renderTeam();
 else if(page==='partners')renderPartners();
 else if(page==='project')renderProject();
 else if(page==='partner')renderPartner();
 else if(page==='news')renderNews();
 else if(page==='explainer')renderExplainer();
 else if(page==='faq')renderFaq();
 else if(page==='blog')renderBlog();
 else if(page==='contact')renderContact();

 // reveals
 var rIO=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');rIO.unobserve(e.target);}});},{threshold:.12});
 document.querySelectorAll('.fade').forEach(function(e){rIO.observe(e);});
 // count-up strips
 document.querySelectorAll('[data-countgroup]').forEach(function(grp){
   var sIO=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){[].forEach.call(e.target.querySelectorAll('.n'),function(n,i){if(n.dataset.to)setTimeout(function(){countUp(n,1400);},i*120);});sIO.disconnect();}});},{threshold:.4});
   sIO.observe(grp);});
 // nav stick + progress bar
 var bar=el('bar');
 function onScroll(){var hdr=el('hdr');if(hdr)hdr.classList.toggle('stuck',window.scrollY>24);
   if(bar){var h=document.documentElement.scrollHeight-window.innerHeight;bar.style.width=(h>0?window.scrollY/h*100:0)+'%';}}
 window.addEventListener('scroll',onScroll,{passive:true});onScroll();
}
if(document.readyState!=='loading')init();else document.addEventListener('DOMContentLoaded',init);
})();
