# PAPINGU theme (Not For Sale)

A WordPress block theme that renders the approved NFS prototype faithfully by loading the
prototype's own design system and engine, not a reinterpretation.

## How fidelity is achieved
- `assets/css/styles.css` is the prototype design system, verbatim.
- `assets/js/app.js` is the prototype engine (injects header/newsletter/footer, generates the
  inline-SVG artwork, renders each page, and handles all interactions). Internal links were
  rewritten to WordPress paths and the FAQ content was replaced with the real NFS answers.
- `assets/js/flags.js` is the embedded flag set, verbatim.
- `parts/header.html` and `parts/footer.html` hold the `#bar` / `#site-header` /
  `#site-newsletter` / `#site-footer` placeholders the engine fills.
- Each template reproduces the matching prototype page markup and sets `data-page` so the engine
  renders that page exactly as designed.

## Templates
- `front-page.html` (home), `single.html` (article), `index.html` (news fallback)
- Custom page templates (assign via the page editor, Template panel):
  NFS: Projects index, Project (single), Partners index, Partner (single), About, Team,
  News index, Explainer, FAQ
- `page.html` (generic), `404.html`

## Setup on staging
1. Upload and activate the theme.
2. Create Pages (Projects, Project, Partners, Partner, About, Team, News, Explainer, FAQ) and
   assign the matching "NFS:" template to each. Set Home to a static front page.
3. Permalinks: Post name.

## Honest status
This makes the **design** pixel-faithful to your prototype now. Dynamic content (news, projects,
partners) still renders from the engine's data arrays. Binding real WordPress/CPT content into the
same markup (so editors manage it) is the next step, the design layer it slots into is now correct.
