<?php
/**
 * NFS Core - reCAPTCHA helpers.
 * Keys live on the unified NFS Settings page (see settings.php). This file only
 * enqueues the API, renders the widget, and verifies tokens server-side.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Enqueue the reCAPTCHA API when enabled + a site key is present. */
add_action( 'wp_enqueue_scripts', function () {
	$en  = (int) nfs_get( 'rc_enabled' );
	$site = nfs_get( 'rc_site' );
	if ( ! $en || ! $site ) { return; }

	if ( 'v3' === nfs_get( 'rc_version' ) ) {
		wp_enqueue_script( 'nfs-recaptcha-api', 'https://www.google.com/recaptcha/api.js?render=' . rawurlencode( $site ), array(), null, true );
		$js = "document.addEventListener('submit',function(e){var f=e.target;if(!f.classList.contains('nfs-protected'))return;if(f.dataset.nfsToken)return;e.preventDefault();grecaptcha.ready(function(){grecaptcha.execute('" . esc_js( $site ) . "',{action:'submit'}).then(function(t){var i=document.createElement('input');i.type='hidden';i.name='g-recaptcha-response';i.value=t;f.appendChild(i);f.dataset.nfsToken='1';f.submit();});});});";
		wp_add_inline_script( 'nfs-recaptcha-api', $js );
	} else {
		wp_enqueue_script( 'nfs-recaptcha-api', 'https://www.google.com/recaptcha/api.js', array(), null, true );
	}
} );

/** Markup for a v2 widget (v3 needs no markup, just class="nfs-protected" on the form). */
function nfs_recaptcha_field() {
	$en = (int) nfs_get( 'rc_enabled' );
	$site = nfs_get( 'rc_site' );
	if ( ! $en || ! $site ) { return ''; }
	if ( 'v3' === nfs_get( 'rc_version' ) ) { return ''; }
	return '<div class="g-recaptcha" data-sitekey="' . esc_attr( $site ) . '"></div>';
}
add_shortcode( 'nfs_recaptcha', 'nfs_recaptcha_field' );

/** Verify a token. Returns true if disabled, or if it passes (and clears v3 threshold). */
function nfs_recaptcha_verify( $token = null, $remote_ip = null ) {
	if ( ! (int) nfs_get( 'rc_enabled' ) || ! nfs_get( 'rc_secret' ) ) { return true; }
	if ( empty( $token ) ) { return false; }
	$resp = wp_remote_post( 'https://www.google.com/recaptcha/api/siteverify', array(
		'timeout' => 8,
		'body'    => array(
			'secret'   => nfs_get( 'rc_secret' ),
			'response' => $token,
			'remoteip' => $remote_ip ? $remote_ip : ( isset( $_SERVER['REMOTE_ADDR'] ) ? $_SERVER['REMOTE_ADDR'] : '' ),
		),
	) );
	if ( is_wp_error( $resp ) ) { return false; }
	$d = json_decode( wp_remote_retrieve_body( $resp ), true );
	if ( empty( $d['success'] ) ) { return false; }
	if ( 'v3' === nfs_get( 'rc_version' ) && isset( $d['score'] ) ) {
		return floatval( $d['score'] ) >= floatval( nfs_get( 'rc_threshold' ) );
	}
	return true;
}
