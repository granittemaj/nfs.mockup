<?php
/**
 * NFS Core - unified settings.
 * One admin page (NFS Settings) for branding, newsletter, contact/social, and reCAPTCHA.
 * Secret key is write-only: never rendered back to the browser.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

const NFS_OPTION = 'nfs_settings';

function nfs_defaults() {
	return array(
		'logo_url'        => 'https://stg.wearenotforsale.org/wp-content/uploads/2025/11/logo-1-e1781208606205.png',
		'favicon_url'     => 'https://stg.wearenotforsale.org/wp-content/uploads/2025/12/NFS_favicon.png',
		'mailchimp_action'=> '',
		'feed_base'       => 'https://automation.wearenotforsale.org',
		'contact_email'   => 'team@wearenotforsale.org',
		'address'         => '1930 Village Center Circle #3-19535, Las Vegas, NV 89134, USA',
		'donor_login_url' => 'https://pro.gofundme.com/sso',
		'ig'              => 'https://www.instagram.com/nfs/',
		'fb'              => 'https://www.facebook.com/notforsale',
		'li'              => 'https://www.linkedin.com/company/notforsale/',
		'tt'              => 'https://www.tiktok.com/@wearenotforsale',
		'cover_ht_style'    => 'blend','cover_ht_treat'    => 'duotone',
		'cover_eco_style'   => 'blend','cover_eco_treat'   => 'grade',
		'cover_si_style'    => 'blend','cover_si_treat'    => 'card',
		'cover_cyber_style' => 'scene','cover_cyber_treat' => 'duotone',
		'cover_default_style'=> 'auto','cover_default_treat'=> 'duotone',
		'rc_enabled'      => 0,
		'rc_version'      => 'v2',
		'rc_site'         => '',
		'rc_secret'       => '',
		'rc_threshold'    => '0.5',
	);
}
function nfs_get( $key = null ) {
	$o = wp_parse_args( get_option( NFS_OPTION, array() ), nfs_defaults() );
	return is_null( $key ) ? $o : ( isset( $o[ $key ] ) ? $o[ $key ] : null );
}

/* ---------------- Admin menu ---------------- */
add_action( 'admin_menu', function () {
	add_menu_page( 'NFS Settings', 'NFS Settings', 'manage_options', 'nfs-settings', 'nfs_settings_page', 'dashicons-shield-alt', 59 );
} );

add_action( 'admin_init', function () {
	register_setting( 'nfs_settings_group', NFS_OPTION, 'nfs_settings_sanitize' );

	$page = 'nfs-settings';
	$txt = function ( $id, $label, $section, $type = 'text', $desc = '' ) use ( $page ) {
		add_settings_field( $id, $label, function () use ( $id, $type, $desc ) {
			$val = nfs_get( $id );
			printf( '<input type="%s" class="regular-text" name="%s[%s]" value="%s" autocomplete="off">',
				esc_attr( $type ), NFS_OPTION, esc_attr( $id ), esc_attr( $val ) );
			if ( $desc ) { echo '<p class="description">' . wp_kses_post( $desc ) . '</p>'; }
		}, $page, $section );
	};

	// Branding
	add_settings_section( 'nfs_brand', 'Branding', '__return_false', $page );
	$txt( 'logo_url', 'Logo URL', 'nfs_brand', 'url', 'Shown in the header and mobile menu.' );
	$txt( 'favicon_url', 'Favicon URL', 'nfs_brand', 'url', 'Used unless a Site Icon is set under Settings &rarr; General.' );

	// Newsletter
	add_settings_section( 'nfs_news', 'Newsletter (Mailchimp)', '__return_false', $page );
	$txt( 'mailchimp_action', 'Mailchimp form action URL', 'nfs_news', 'url', 'Mailchimp &rarr; Audience &rarr; Signup forms &rarr; Embedded form: copy the <code>&lt;form action="..."&gt;</code> URL.' );

	// Automation feeds
	add_settings_section( 'nfs_feeds', 'Automation feeds', function () {
		echo '<p>JSON endpoints from NFS Automation. Project updates show on each project page; jobs power the Job Opportunities page.</p>';
	}, $page );
	$txt( 'feed_base', 'Automation base URL', 'nfs_feeds', 'url', 'NFS Automation origin only, e.g. <code>https://automation.wearenotforsale.org</code>. Paths (<code>/api/feed/v1/updates</code>, <code>/api/feed/v1/jobs</code>) are fixed.' );

	// Contact & social
	add_settings_section( 'nfs_contact', 'Contact &amp; Social', '__return_false', $page );
	$txt( 'contact_email', 'Contact email', 'nfs_contact', 'email', 'Where the contact form is delivered.' );
	$txt( 'address', 'Postal address', 'nfs_contact' );
	$txt( 'donor_login_url', 'Donor login URL', 'nfs_contact', 'url' );
	$txt( 'ig', 'Instagram URL', 'nfs_contact', 'url' );
	$txt( 'fb', 'Facebook URL', 'nfs_contact', 'url' );
	$txt( 'li', 'LinkedIn URL', 'nfs_contact', 'url' );
	$txt( 'tt', 'TikTok URL', 'nfs_contact', 'url' );

	// Covers (per category)
	add_settings_section( 'nfs_cover', 'Covers (per category)', function () {
		echo '<p>Default cover treatment per Theme. Any story can override these in its editor.</p>';
	}, $page );
	$cover_row = function ( $key, $label ) use ( $page ) {
		add_settings_field( 'cover_' . $key, $label, function () use ( $key ) {
			$styles = array( 'auto'=>'Auto (photo, else scene)', 'photo'=>'Photo', 'scene'=>'Scene', 'blend'=>'Blend' );
			$treats = array( 'duotone'=>'Duotone', 'card'=>'Card', 'grade'=>'Grade' );
			$sv = nfs_get( 'cover_' . $key . '_style' ); $tv = nfs_get( 'cover_' . $key . '_treat' );
			echo '<select name="' . NFS_OPTION . '[cover_' . $key . '_style]">';
			foreach ( $styles as $k=>$v ) { echo '<option value="' . esc_attr($k) . '" ' . selected($k,$sv,false) . '>' . esc_html($v) . '</option>'; }
			echo '</select> &nbsp; ';
			echo '<select name="' . NFS_OPTION . '[cover_' . $key . '_treat]">';
			foreach ( $treats as $k=>$v ) { echo '<option value="' . esc_attr($k) . '" ' . selected($k,$tv,false) . '>' . esc_html($v) . ' (blend)</option>'; }
			echo '</select>';
		}, $page, 'nfs_cover' );
	};
	$cover_row( 'ht', 'Human Trafficking' );
	$cover_row( 'eco', 'Ecocide' );
	$cover_row( 'si', 'Social Innovation' );
	$cover_row( 'cyber', 'Cyber Scams' );
	$cover_row( 'default', 'Other / untagged' );

	// reCAPTCHA
	add_settings_section( 'nfs_rc', 'reCAPTCHA', function () {
		echo '<p>Create keys at <a href="https://www.google.com/recaptcha/admin" target="_blank" rel="noopener">google.com/recaptcha/admin</a>. The secret key is stored encrypted-at-rest by your host and never shown again after saving.</p>';
	}, $page );

	add_settings_field( 'rc_enabled', 'Enable', function () {
		echo '<label><input type="checkbox" name="' . NFS_OPTION . '[rc_enabled]" value="1" ' . checked( 1, nfs_get( 'rc_enabled' ), false ) . '> Active</label>';
	}, $page, 'nfs_rc' );
	add_settings_field( 'rc_version', 'Version', function () {
		$v = nfs_get( 'rc_version' );
		echo '<label style="margin-right:14px"><input type="radio" name="' . NFS_OPTION . '[rc_version]" value="v2" ' . checked( 'v2', $v, false ) . '> v2 checkbox</label>';
		echo '<label><input type="radio" name="' . NFS_OPTION . '[rc_version]" value="v3" ' . checked( 'v3', $v, false ) . '> v3 invisible</label>';
	}, $page, 'nfs_rc' );
	add_settings_field( 'rc_site', 'Site key', function () {
		printf( '<input type="text" class="regular-text" name="%s[rc_site]" value="%s" autocomplete="off">', NFS_OPTION, esc_attr( nfs_get( 'rc_site' ) ) );
	}, $page, 'nfs_rc' );
	add_settings_field( 'rc_secret', 'Secret key', function () {
		$has = (bool) nfs_get( 'rc_secret' );
		printf( '<input type="password" class="regular-text" name="%s[rc_secret]" value="" autocomplete="new-password" placeholder="%s">',
			NFS_OPTION, $has ? '\u2022\u2022\u2022\u2022\u2022\u2022 saved (leave blank to keep)' : 'Enter secret key' );
		echo '<p class="description">Write-only. Leave blank to keep the saved key. Never displayed back.</p>';
	}, $page, 'nfs_rc' );
	add_settings_field( 'rc_threshold', 'v3 threshold', function () {
		printf( '<input type="number" step="0.1" min="0" max="1" name="%s[rc_threshold]" value="%s"> <span class="description">0.0 lax - 1.0 strict (v3 only)</span>', NFS_OPTION, esc_attr( nfs_get( 'rc_threshold' ) ) );
	}, $page, 'nfs_rc' );
} );

function nfs_settings_sanitize( $in ) {
	$cur = nfs_get();
	$out = $cur;
	$urls = array( 'logo_url','favicon_url','mailchimp_action','donor_login_url','ig','fb','li','tt' );
	foreach ( $urls as $k ) { if ( isset( $in[ $k ] ) ) { $out[ $k ] = esc_url_raw( trim( $in[ $k ] ) ); } }
	if ( isset( $in['feed_base'] ) ) { $out['feed_base'] = esc_url_raw( trim( $in['feed_base'] ) ); }
	$out['contact_email'] = isset( $in['contact_email'] ) ? sanitize_email( $in['contact_email'] ) : $cur['contact_email'];
	$out['address']       = isset( $in['address'] ) ? sanitize_text_field( $in['address'] ) : $cur['address'];
	$styles_wl=array('auto','photo','scene','blend'); $treats_wl=array('duotone','card','grade');
	foreach ( array('ht','eco','si','cyber','default') as $ck ) {
		$sk='cover_'.$ck.'_style'; $tk='cover_'.$ck.'_treat';
		$out[$sk] = ( isset($in[$sk]) && in_array($in[$sk],$styles_wl,true) ) ? $in[$sk] : $cur[$sk];
		$out[$tk] = ( isset($in[$tk]) && in_array($in[$tk],$treats_wl,true) ) ? $in[$tk] : $cur[$tk];
	}
	$out['rc_enabled']    = empty( $in['rc_enabled'] ) ? 0 : 1;
	$out['rc_version']    = ( isset( $in['rc_version'] ) && 'v3' === $in['rc_version'] ) ? 'v3' : 'v2';
	$out['rc_site']       = isset( $in['rc_site'] ) ? sanitize_text_field( $in['rc_site'] ) : $cur['rc_site'];
	$out['rc_threshold']  = isset( $in['rc_threshold'] ) ? (string) max( 0, min( 1, floatval( $in['rc_threshold'] ) ) ) : $cur['rc_threshold'];
	// secret: write-only, blank submission keeps existing
	if ( isset( $in['rc_secret'] ) && '' !== trim( $in['rc_secret'] ) ) {
		$out['rc_secret'] = sanitize_text_field( trim( $in['rc_secret'] ) );
	}
	return $out;
}

function nfs_settings_page() {
	echo '<div class="wrap"><h1>NFS Settings</h1>';
	echo '<p style="max-width:680px">Everything for the site in one place. Branding and contact details feed the theme automatically; reCAPTCHA protects the contact form. Saved here, these survive theme and plugin updates.</p>';
	echo '<form method="post" action="options.php">';
	settings_fields( 'nfs_settings_group' );
	do_settings_sections( 'nfs-settings' );
	submit_button();
	echo '</form>';
	if ( function_exists( 'nfs_seed_button' ) ) { nfs_seed_button(); }
	echo '</div>';
}

/* ---------------- Front-end config (safe values only) ---------------- */
add_action( 'wp_head', function () {
	$o = nfs_get();
	// Favicon (unless a WP Site Icon is set)
	if ( ! ( function_exists( 'has_site_icon' ) && has_site_icon() ) && $o['favicon_url'] ) {
		echo '<link rel="icon" href="' . esc_url( $o['favicon_url'] ) . '" sizes="any">' . "\n";
	}
	$cfg = array(
		'logo'        => $o['logo_url'],
		'mailchimp'   => $o['mailchimp_action'],
		'contactEmail'=> $o['contact_email'],
		'address'     => $o['address'],
		'donorLogin'  => $o['donor_login_url'],
		'social'      => array( 'ig' => $o['ig'], 'fb' => $o['fb'], 'li' => $o['li'], 'tt' => $o['tt'] ),
		'postUrl'     => admin_url( 'admin-post.php' ),
		'contactNonce'=> wp_create_nonce( 'nfs_contact' ),
		'recaptcha'   => array(
			'enabled' => (int) $o['rc_enabled'],
			'version' => $o['rc_version'],
			'site'    => $o['rc_site'], // public key only; secret never leaves the server
		),
	);
	echo '<script>window.NFS_CONFIG=' . wp_json_encode( $cfg ) . ';</script>' . "\n";
}, 1 );
