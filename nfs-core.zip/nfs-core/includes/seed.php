<?php
/**
 * NFS Core - project seeder.
 * One-click import of all country projects (NFS Settings -> Import projects),
 * with region, status, since, and focus areas. Idempotent: existing slugs are skipped.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function nfs_country_data() {
	return array(
		array( 'Argentina','Americas' ), array( 'Bolivia','Americas' ), array( 'Brazil','Americas' ), array( 'Canada','Americas' ),
		array( 'Colombia','Americas' ), array( 'Peru','Americas' ), array( 'United States','Americas' ),
		array( 'Cameroon','Africa' ), array( 'DR Congo','Africa' ), array( 'Guinea','Africa' ), array( 'Madagascar','Africa' ),
		array( 'Mozambique','Africa' ), array( 'Rwanda','Africa' ), array( 'Senegal','Africa' ), array( 'South Africa','Africa' ),
		array( 'Tanzania','Africa' ), array( 'Uganda','Africa' ),
		array( 'Italy','Europe' ), array( 'Netherlands','Europe' ), array( 'Sweden','Europe' ), array( 'United Kingdom','Europe' ),
		array( 'Australia','Asia-Pacific' ), array( 'Japan','Asia-Pacific' ), array( 'Laos','Asia-Pacific' ),
		array( 'Myanmar','Asia-Pacific' ), array( 'Thailand','Asia-Pacific' ), array( 'Vietnam','Asia-Pacific' ),
	);
}
function nfs_work_countries() {
	return array( 'Netherlands','Vietnam','South Africa','Mozambique','Thailand','Laos','Myanmar','Uganda','DR Congo','Peru','United States' );
}
function nfs_region_focus( $region ) {
	$m = array(
		'Americas'     => array( 'Survivor care','Prevention','Reforestation' ),
		'Africa'       => array( 'Reintegration','Education','Agroforestry' ),
		'Europe'       => array( 'Aftercare','Vocational training','Advocacy' ),
		'Asia-Pacific' => array( 'Rescue','Safe homes','Education' ),
	);
	return isset( $m[ $region ] ) ? $m[ $region ] : array( 'Prevention','Protection','Opportunity' );
}
function nfs_region_since( $region ) {
	$m = array( 'Americas'=>'2014','Africa'=>'2011','Europe'=>'2013','Asia-Pacific'=>'2012' );
	return isset( $m[ $region ] ) ? $m[ $region ] : '2012';
}

function nfs_seed_projects() {
	$lead = "Every Not For Sale programme begins with the same question: what makes people here vulnerable, and how do we close that gap before traffickers exploit it? On the ground, that means working with local partners who know their communities best, combining prevention, protection, and long-term opportunity.\n\nReplace this with the real programme story and outcomes for this country.";
	$work = nfs_work_countries();
	$created = 0; $skipped = 0;

	foreach ( nfs_country_data() as $c ) {
		list( $name, $region ) = $c;
		$slug = sanitize_title( $name );
		$exists = get_posts( array( 'post_type'=>'project', 'name'=>$slug, 'post_status'=>'any', 'numberposts'=>1, 'fields'=>'ids' ) );
		if ( $exists ) { $skipped++; continue; }

		$id = wp_insert_post( array(
			'post_type'    => 'project',
			'post_status'  => 'publish',
			'post_title'   => $name,
			'post_name'    => $slug,
			'post_content' => $lead,
		) );
		if ( ! $id || is_wp_error( $id ) ) { continue; }

		wp_set_object_terms( $id, $region, 'region' );

		$status = in_array( $name, $work, true ) ? 'Active programme' : 'Active programme';
		$focus  = implode( "\n", nfs_region_focus( $region ) );
		$since  = nfs_region_since( $region );
		if ( function_exists( 'update_field' ) ) {
			update_field( 'status', $status, $id );
			update_field( 'since', $since, $id );
			update_field( 'focus_areas', $focus, $id );
		} else {
			update_post_meta( $id, 'status', $status );
			update_post_meta( $id, 'since', $since );
			update_post_meta( $id, 'focus_areas', $focus );
		}
		$created++;
	}
	return array( $created, $skipped );
}

/* Admin-post handler for the import button. */
add_action( 'admin_post_nfs_seed_projects', function () {
	if ( ! current_user_can( 'manage_options' ) || empty( $_POST['_wpnonce'] ) || ! wp_verify_nonce( $_POST['_wpnonce'], 'nfs_seed_projects' ) ) {
		wp_die( 'Not allowed' );
	}
	list( $created, $skipped ) = nfs_seed_projects();
	wp_safe_redirect( add_query_arg( array( 'page'=>'nfs-settings', 'seeded'=>$created . '.' . $skipped ), admin_url( 'admin.php' ) ) );
	exit;
} );

/** Render the import button (called from the settings page). */
function nfs_seed_button() {
	$count = wp_count_posts( 'project' );
	$have  = isset( $count->publish ) ? (int) $count->publish : 0;
	echo '<hr><h2>Projects</h2>';
	if ( isset( $_GET['seeded'] ) ) {
		list( $c, $s ) = array_pad( explode( '.', sanitize_text_field( $_GET['seeded'] ) ), 2, '0' );
		echo '<div class="notice notice-success inline"><p>Imported ' . (int) $c . ' projects (' . (int) $s . ' already existed).</p></div>';
	}
	echo '<p>Currently ' . $have . ' projects. Click to import the full country list (27). Safe to run more than once, existing countries are skipped.</p>';
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	echo '<input type="hidden" name="action" value="nfs_seed_projects">';
	wp_nonce_field( 'nfs_seed_projects' );
	submit_button( 'Import country projects', 'secondary' );
	echo '</form>';
}
