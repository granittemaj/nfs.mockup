<?php
/**
 * NFS Core - Taxonomies
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function nfs_core_register_taxonomies() {

	// Theme -> applies to Story (Human Trafficking, Social Innovation, Ecocide, Cyber Scams)
	register_taxonomy( 'nfs_theme', array( 'story' ), array(
		'labels' => array(
			'name'          => 'Themes',
			'singular_name' => 'Theme',
			'menu_name'     => 'Themes',
			'all_items'     => 'All Themes',
			'edit_item'     => 'Edit Theme',
			'add_new_item'  => 'Add New Theme',
			'search_items'  => 'Search Themes',
		),
		'public'            => true,
		'hierarchical'      => true,
		'show_in_rest'      => true,
		'show_admin_column' => true,
		'rewrite'           => array( 'slug' => 'theme', 'with_front' => false ),
	) );

	// Region -> applies to Project (Americas, Africa, Europe, Asia-Pacific)
	register_taxonomy( 'region', array( 'project' ), array(
		'labels' => array(
			'name'          => 'Regions',
			'singular_name' => 'Region',
			'menu_name'     => 'Regions',
			'all_items'     => 'All Regions',
			'edit_item'     => 'Edit Region',
			'add_new_item'  => 'Add New Region',
			'search_items'  => 'Search Regions',
		),
		'public'            => true,
		'hierarchical'      => true,
		'show_in_rest'      => true,
		'show_admin_column' => true,
		'rewrite'           => array( 'slug' => 'region', 'with_front' => false ),
	) );
}
add_action( 'init', 'nfs_core_register_taxonomies' );

/**
 * Seed default terms on activation so editors start with the right set.
 */
function nfs_core_seed_terms() {
	$themes = array( 'Human Trafficking', 'Social Innovation', 'Ecocide', 'Cyber Scams' );
	foreach ( $themes as $t ) {
		if ( ! term_exists( $t, 'nfs_theme' ) ) {
			wp_insert_term( $t, 'nfs_theme' );
		}
	}
	$regions = array( 'Americas', 'Africa', 'Europe', 'Asia-Pacific' );
	foreach ( $regions as $r ) {
		if ( ! term_exists( $r, 'region' ) ) {
			wp_insert_term( $r, 'region' );
		}
	}
}
add_action( 'init', 'nfs_core_seed_terms', 20 );
