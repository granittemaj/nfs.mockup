<?php
/**
 * NFS Core - contact form handler.
 * The theme renders the form (action = admin-post.php, action field = nfs_contact).
 * Here we validate and email it to the configured contact address.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function nfs_handle_contact() {
	$back = wp_get_referer() ? wp_get_referer() : home_url( '/contact/' );

	// Nonce
	if ( empty( $_POST['_wpnonce'] ) || ! wp_verify_nonce( $_POST['_wpnonce'], 'nfs_contact' ) ) {
		wp_safe_redirect( add_query_arg( 'nfs', 'error', $back ) ); exit;
	}
	// Honeypot (bots fill this hidden field)
	if ( ! empty( $_POST['nfs_hp'] ) ) {
		wp_safe_redirect( add_query_arg( 'nfs', 'sent', $back ) ); exit; // pretend success
	}
	// reCAPTCHA
	$token = isset( $_POST['g-recaptcha-response'] ) ? $_POST['g-recaptcha-response'] : '';
	if ( ! nfs_recaptcha_verify( $token ) ) {
		wp_safe_redirect( add_query_arg( 'nfs', 'captcha', $back ) ); exit;
	}

	$name    = isset( $_POST['nfs_name'] ) ? sanitize_text_field( $_POST['nfs_name'] ) : '';
	$email   = isset( $_POST['nfs_email'] ) ? sanitize_email( $_POST['nfs_email'] ) : '';
	$message = isset( $_POST['nfs_message'] ) ? sanitize_textarea_field( $_POST['nfs_message'] ) : '';

	if ( ! $name || ! is_email( $email ) || ! $message ) {
		wp_safe_redirect( add_query_arg( 'nfs', 'invalid', $back ) ); exit;
	}

	$to      = nfs_get( 'contact_email' );
	$subject = 'Website contact form: ' . wp_specialchars_decode( $name );
	$body    = "Name: {$name}\nEmail: {$email}\n\n{$message}\n";
	$headers = array( 'Reply-To: ' . $name . ' <' . $email . '>' );

	$ok = wp_mail( $to, $subject, $body, $headers );
	wp_safe_redirect( add_query_arg( 'nfs', $ok ? 'sent' : 'error', $back ) );
	exit;
}
add_action( 'admin_post_nofncts_dummy', '__return_false' ); // no-op guard
add_action( 'admin_post_nfs_contact', 'nfs_handle_contact' );
add_action( 'admin_post_nopriv_nfs_contact', 'nfs_handle_contact' );
