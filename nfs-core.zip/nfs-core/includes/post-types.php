<?php
/**
 * NFS Core - Custom Post Types
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function nfs_core_register_post_types() {

	// Project (country programmes) -> /projects/{slug}/
	register_post_type( 'project', array(
		'labels' => nfs_core_labels( 'Project', 'Projects' ),
		'public' => true,
		'has_archive' => true,
		'menu_icon' => 'dashicons-location-alt',
		'menu_position' => 21,
		'show_in_rest' => true,
		'supports' => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions', 'page-attributes' ),
		'rewrite' => array( 'slug' => 'projects', 'with_front' => false ),
	) );

	// Partner (corporate partners) -> /partners/{slug}/
	register_post_type( 'partner', array(
		'labels' => nfs_core_labels( 'Partner', 'Partners' ),
		'public' => true,
		'has_archive' => true,
		'menu_icon' => 'dashicons-groups',
		'menu_position' => 22,
		'show_in_rest' => true,
		'supports' => array( 'title', 'editor', 'thumbnail', 'revisions', 'page-attributes' ),
		'rewrite' => array( 'slug' => 'partners', 'with_front' => false ),
	) );

	// Story (news / investigations / explainers) -> /news/{slug}/
	register_post_type( 'story', array(
		'labels' => nfs_core_labels( 'Story', 'Stories' ),
		'public' => true,
		'has_archive' => true,
		'menu_icon' => 'dashicons-megaphone',
		'menu_position' => 20,
		'show_in_rest' => true,
		'supports' => array( 'title', 'editor', 'excerpt', 'thumbnail', 'author', 'revisions', 'comments' ),
		'rewrite' => array( 'slug' => 'news', 'with_front' => false ),
	) );

	// Team Member (founders + directors) -> /team/{slug}/
	register_post_type( 'team_member', array(
		'labels' => nfs_core_labels( 'Team Member', 'Team' ),
		'public' => true,
		'has_archive' => true,
		'menu_icon' => 'dashicons-businessperson',
		'menu_position' => 23,
		'show_in_rest' => true,
		'supports' => array( 'title', 'editor', 'thumbnail', 'revisions', 'page-attributes' ),
		'rewrite' => array( 'slug' => 'team', 'with_front' => false ),
	) );
}
add_action( 'init', 'nfs_core_register_post_types' );

/**
 * Helper: build a standard labels array.
 */
function nfs_core_labels( $singular, $plural ) {
	return array(
		'name'               => $plural,
		'singular_name'      => $singular,
		'menu_name'          => $plural,
		'add_new'            => 'Add New',
		'add_new_item'       => 'Add New ' . $singular,
		'edit_item'          => 'Edit ' . $singular,
		'new_item'           => 'New ' . $singular,
		'view_item'          => 'View ' . $singular,
		'view_items'         => 'View ' . $plural,
		'search_items'       => 'Search ' . $plural,
		'not_found'          => 'No ' . strtolower( $plural ) . ' found',
		'not_found_in_trash' => 'No ' . strtolower( $plural ) . ' found in Trash',
		'all_items'          => 'All ' . $plural,
		'archives'           => $singular . ' Archives',
	);
}
