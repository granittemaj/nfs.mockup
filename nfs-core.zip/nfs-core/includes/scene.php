<?php
/**
 * NFS Core - scene generator (PHP port) + cover composer.
 * Deterministic landscape scenes (seeded by title, biased by Theme) rendered
 * as inline SVG, plus the cover system: Auto / Photo / Scene / Blend
 * (Duotone | Card | Grade), with per-category defaults and per-story overrides.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ---------------- palettes (mirror of the JS engine) ---------------- */
function nfs_pal() {
	return array(
		array( 's1'=>'#f4d9b8','s2'=>'#e7ad77','sun'=>'#f0915a','h'=>array('#d98a52','#bf6f3e','#8f4f2c') ),
		array( 's1'=>'#dde8ee','s2'=>'#a9c3cf','sun'=>'#f4efe4','h'=>array('#8aa2ad','#62808d','#3f5b66') ),
		array( 's1'=>'#dde7cf','s2'=>'#a9c191','sun'=>'#eef0d6','h'=>array('#7e9a64','#5b7747','#3a5430') ),
		array( 's1'=>'#cfe6e8','s2'=>'#9cc6cc','sun'=>'#f6e7c8','h'=>array('#79b0b0','#4f8e92','#356c70') ),
		array( 's1'=>'#f3e6c4','s2'=>'#e6c98a','sun'=>'#f4a259','h'=>array('#cba85e','#a98742','#7a5d2c') ),
		array( 's1'=>'#e9dfe9','s2'=>'#c8b6c9','sun'=>'#f3e3ea','h'=>array('#a591a8','#7e6781','#574258') ),
		array( 's1'=>'#fbe3d0','s2'=>'#f6b98e','sun'=>'#f58a4b','h'=>array('#e3936a','#c46f49','#8f4d31') ),
		array( 's1'=>'#e7ecef','s2'=>'#cdd6db','sun'=>'#eef2f3','h'=>array('#9fb0b8','#76898f','#516167') ),
	);
}
function nfs_cat_pal() {
	return array(
		'Human Trafficking' => array(0,6),
		'Social Innovation' => array(3),
		'Social Enterprise' => array(3),
		'Ecocide'           => array(2),
		'Cyber Scams'       => array(1,7),
	);
}
/** Named palette override -> PAL index. */
function nfs_palette_override_index( $name ) {
	$m = array( 'clay'=>0, 'teal'=>3, 'green'=>2, 'slate'=>1 );
	$name = strtolower( (string) $name );
	return isset( $m[ $name ] ) ? $m[ $name ] : null;
}

/* ---------------- deterministic math (mirror of JS) ---------------- */
function nfs_imul32( $a, $b ) {
	$a &= 0xFFFFFFFF; $b &= 0xFFFFFFFF;
	$ah = ( $a >> 16 ) & 0xFFFF; $al = $a & 0xFFFF;
	$bh = ( $b >> 16 ) & 0xFFFF; $bl = $b & 0xFFFF;
	return ( ( $al * $bl ) + ( ( ( $ah * $bl + $al * $bh ) & 0xFFFF ) << 16 ) ) & 0xFFFFFFFF;
}
function nfs_hash( $str ) {
	$h = 2166136261; $len = strlen( $str );
	for ( $i = 0; $i < $len; $i++ ) {
		$h ^= ord( $str[ $i ] );
		$h = nfs_imul32( $h, 16777619 );
	}
	return $h & 0xFFFFFFFF;
}
/** Returns a callable PRNG (mulberry32). */
function nfs_rng( $seed ) {
	$state = array( $seed & 0xFFFFFFFF );
	return function () use ( &$state ) {
		$state[0] = ( $state[0] + 0x6D2B79F5 ) & 0xFFFFFFFF;
		$s = $state[0];
		$t = nfs_imul32( $s ^ ( $s >> 15 ), $s | 1 );
		$t = ( ( ( $t + nfs_imul32( $t ^ ( $t >> 7 ), $t | 61 ) ) & 0xFFFFFFFF ) ^ $t ) & 0xFFFFFFFF;
		return ( ( $t ^ ( $t >> 14 ) ) & 0xFFFFFFFF ) / 4294967296;
	};
}
function nfs_hill( $baseY, $amp, $r ) {
	$n = 5; $p = array();
	for ( $i = 0; $i <= $n; $i++ ) { $p[] = array( $i / $n * 100, $baseY + ( $r() * 2 - 1 ) * $amp ); }
	$d = 'M0 100 L0 ' . sprintf( '%.1f', $p[0][1] );
	for ( $i = 1; $i <= $n; $i++ ) {
		$d .= ' Q ' . sprintf( '%.1f', $p[ $i-1 ][0] ) . ' ' . sprintf( '%.1f', $p[ $i-1 ][1] )
		   . ' ' . sprintf( '%.1f', ( $p[ $i-1 ][0] + $p[ $i ][0] ) / 2 )
		   . ' ' . sprintf( '%.1f', ( $p[ $i-1 ][1] + $p[ $i ][1] ) / 2 );
	}
	$d .= ' L100 ' . sprintf( '%.1f', $p[ $n ][1] ) . ' L100 100 Z';
	return $d;
}
/** Resolve the palette for a seed/category/override. */
function nfs_resolve_palette( $seed, $cat = '', $override_idx = null ) {
	$PAL = nfs_pal(); $h = nfs_hash( $seed );
	if ( ! is_null( $override_idx ) ) { return $PAL[ $override_idx % 8 ]; }
	$CAT = nfs_cat_pal();
	if ( $cat && isset( $CAT[ $cat ] ) ) {
		$pl = $CAT[ $cat ]; return $PAL[ $pl[ $h % count( $pl ) ] ];
	}
	return $PAL[ $h % 8 ];
}
/** Inner SVG (defs + shapes), no outer <svg>. */
function nfs_scene_inner( $seed, $cat = '', $override_idx = null ) {
	$h = nfs_hash( $seed ); $r = nfs_rng( $h );
	$pal = nfs_resolve_palette( $seed, $cat, $override_idx );
	$sx = sprintf( '%.0f', 18 + $r() * 64 );
	$sy = sprintf( '%.0f', 22 + $r() * 22 );
	$sr = 11 + $r() * 7;
	$id = 'g' . $h;
	$a = nfs_hill( 58, 7, nfs_rng( nfs_hash( $seed . 'a' ) ) );
	$b = nfs_hill( 70, 9, nfs_rng( nfs_hash( $seed . 'b' ) ) );
	$c = nfs_hill( 83, 8, nfs_rng( nfs_hash( $seed . 'c' ) ) );
	return '<defs><linearGradient id="' . $id . '" x1="0" y1="0" x2="0" y2="1">'
		. '<stop offset="0" stop-color="' . $pal['s1'] . '"/><stop offset="1" stop-color="' . $pal['s2'] . '"/></linearGradient>'
		. '<radialGradient id="' . $id . 's"><stop offset="0" stop-color="' . $pal['sun'] . '" stop-opacity=".95"/>'
		. '<stop offset="1" stop-color="' . $pal['sun'] . '" stop-opacity="0"/></radialGradient></defs>'
		. '<rect width="100" height="100" fill="url(#' . $id . ')"/>'
		. '<circle cx="' . $sx . '" cy="' . $sy . '" r="' . sprintf( '%.1f', $sr ) . '" fill="' . $pal['sun'] . '"/>'
		. '<circle cx="' . $sx . '" cy="' . $sy . '" r="' . sprintf( '%.1f', $sr * 2.4 ) . '" fill="url(#' . $id . 's)"/>'
		. '<path d="' . $a . '" fill="' . $pal['h'][0] . '" opacity=".92"/>'
		. '<path d="' . $b . '" fill="' . $pal['h'][1] . '" opacity=".95"/>'
		. '<path d="' . $c . '" fill="' . $pal['h'][2] . '"/>';
}
function nfs_scene_svg( $seed, $cat = '', $override_idx = null ) {
	return '<svg class="nfs-scene" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice">'
		. nfs_scene_inner( $seed, $cat, $override_idx ) . '</svg>';
}

/* ---------------- duotone filter ---------------- */
function nfs_hex_triplet( $hex ) {
	$hex = ltrim( $hex, '#' );
	return array( hexdec( substr($hex,0,2) ) / 255, hexdec( substr($hex,2,2) ) / 255, hexdec( substr($hex,4,2) ) / 255 );
}
function nfs_duotone_filter( $fid, $shadow, $hi ) {
	list($sr,$sg,$sb) = nfs_hex_triplet( $shadow );
	list($hr,$hg,$hb) = nfs_hex_triplet( $hi );
	return '<filter id="' . $fid . '" color-interpolation-filters="sRGB">'
		. '<feColorMatrix type="matrix" values="0.33 0.33 0.33 0 0 0.33 0.33 0.33 0 0 0.33 0.33 0.33 0 0 0 0 0 1 0"/>'
		. '<feComponentTransfer>'
		. sprintf( '<feFuncR type="table" tableValues="%.3f %.3f"/>', $sr, $hr )
		. sprintf( '<feFuncG type="table" tableValues="%.3f %.3f"/>', $sg, $hg )
		. sprintf( '<feFuncB type="table" tableValues="%.3f %.3f"/>', $sb, $hb )
		. '</feComponentTransfer></filter>';
}

/* ---------------- cover composer ---------------- */
/**
 * Resolve and render a cover for a post.
 * Reads per-story ACF overrides, falls back to per-category defaults from settings.
 */
function nfs_cover( $post_id, $context = 'cover' ) {
	$terms = get_the_terms( $post_id, 'nfs_theme' );
	$cat   = ( $terms && ! is_wp_error( $terms ) ) ? $terms[0]->name : '';
	$seed  = get_the_title( $post_id );

	// per-story overrides (ACF)
	$ov_style = function_exists( 'get_field' ) ? get_field( 'cover_style', $post_id ) : '';
	$ov_treat = function_exists( 'get_field' ) ? get_field( 'blend_treatment', $post_id ) : '';
	$ov_pal   = function_exists( 'get_field' ) ? get_field( 'scene_palette', $post_id ) : '';

	// per-category defaults (settings)
	$key = nfs_cat_key( $cat );
	$style = ( $ov_style && 'default' !== $ov_style ) ? $ov_style : nfs_get( 'cover_' . $key . '_style' );
	$treat = $ov_treat ? $ov_treat : nfs_get( 'cover_' . $key . '_treat' );
	if ( ! $style ) { $style = 'auto'; }
	if ( ! $treat ) { $treat = 'duotone'; }

	$override_idx = nfs_palette_override_index( $ov_pal ); // null unless clay/teal/green/slate

	$has_photo = has_post_thumbnail( $post_id );
	$photo = $has_photo ? wp_get_attachment_image_url( get_post_thumbnail_id( $post_id ), 'large' ) : '';

	// resolve "auto"
	if ( 'auto' === $style ) { $style = $has_photo ? 'photo' : 'scene'; }
	if ( 'blend' === $style && ! $has_photo ) { $style = 'scene'; }
	if ( 'photo' === $style && ! $has_photo ) { $style = 'scene'; }

	if ( 'photo' === $style ) {
		return '<div class="nfs-cover"><img class="nfs-cover-img" src="' . esc_url( $photo ) . '" alt=""></div>';
	}
	if ( 'scene' === $style ) {
		return '<div class="nfs-cover">' . nfs_scene_svg( $seed, $cat, $override_idx ) . '</div>';
	}

	// blend
	$pal = nfs_resolve_palette( $seed, $cat, $override_idx );
	$h   = nfs_hash( $seed );

	if ( 'card' === $treat ) {
		return '<div class="nfs-cover">' . nfs_scene_svg( $seed, $cat, $override_idx )
			. '<span class="nfs-card"><img src="' . esc_url( $photo ) . '" alt=""></span></div>';
	}
	if ( 'grade' === $treat ) {
		return '<div class="nfs-cover">'
			. '<img class="nfs-cover-img" src="' . esc_url( $photo ) . '" alt="">'
			. '<span class="nfs-grade" style="background:linear-gradient(180deg,' . $pal['s1'] . '00,' . $pal['s2'] . ');mix-blend-mode:multiply"></span>'
			. '<span class="nfs-glow" style="background:radial-gradient(circle at 76% 20%,' . $pal['sun'] . 'cc,' . $pal['sun'] . '00 60%);mix-blend-mode:screen"></span>'
			. '</div>';
	}
	// duotone (default)
	$fid = 'duo' . $h;
	return '<div class="nfs-cover"><svg class="nfs-scene" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice">'
		. '<defs>' . nfs_duotone_filter( $fid, $pal['h'][2], $pal['sun'] ) . '</defs>'
		. nfs_scene_inner( $seed, $cat, $override_idx )
		. '<image href="' . esc_url( $photo ) . '" x="0" y="0" width="100" height="100" preserveAspectRatio="xMidYMid slice" filter="url(#' . $fid . ')" style="mix-blend-mode:multiply" opacity=".95"/>'
		. '</svg></div>';
}

/** Map a theme name to the settings key stub. */
function nfs_cat_key( $cat ) {
	switch ( $cat ) {
		case 'Human Trafficking': return 'ht';
		case 'Ecocide':           return 'eco';
		case 'Social Innovation':
		case 'Social Enterprise': return 'si';
		case 'Cyber Scams':       return 'cyber';
	}
	return 'default';
}
