<?php
/**
 * NFS Core - automation feed client (v1) + renderers.
 * Matches the real NFS Automation feed:
 *   GET /api/feed/v1/updates?project=<slug>&limit=<n>
 *   GET /api/feed/v1/jobs?source=<nfs|partner>&full=1
 * Envelope: { version, generated_at, count, filters, data[] }. We read data[].
 * Server-side only, transient-cached, ETag-revalidated.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! defined( 'NFS_FEED_TTL_UPDATES' ) ) { define( 'NFS_FEED_TTL_UPDATES', 5 * MINUTE_IN_SECONDS ); }
if ( ! defined( 'NFS_FEED_TTL_JOBS' ) )    { define( 'NFS_FEED_TTL_JOBS', 15 * MINUTE_IN_SECONDS ); }

function nfs_feed_base() {
	$b = nfs_get( 'feed_base' );
	return $b ? untrailingslashit( $b ) : 'https://automation.wearenotforsale.org';
}

/** Fetch a feed path, transient-cached, with ETag (If-None-Match / 304). Returns data[] (array). */
function nfs_feed_get( $path, $ttl = NFS_FEED_TTL_UPDATES ) {
	$base = nfs_feed_base();
	if ( ! $base ) { return array(); }
	$key      = 'nfs_feed_' . md5( $base . $path );
	$etag_key = $key . '_etag';
	$cached   = get_transient( $key );
	if ( false !== $cached ) { return is_array( $cached ) ? $cached : array(); }

	$args = array( 'timeout' => 8, 'headers' => array( 'Accept' => 'application/json' ) );
	$etag = get_transient( $etag_key );
	if ( $etag ) { $args['headers']['If-None-Match'] = $etag; }

	$res = wp_remote_get( $base . $path, $args );
	if ( is_wp_error( $res ) ) {
		$prev = get_transient( $key . '_data' );
		return is_array( $prev ) ? $prev : array();
	}
	$code = wp_remote_retrieve_response_code( $res );

	if ( 304 === $code ) {
		$prev = get_transient( $key . '_data' );
		$data = is_array( $prev ) ? $prev : array();
		set_transient( $key, $data, $ttl );
		return $data;
	}
	if ( 200 !== $code ) {
		$prev = get_transient( $key . '_data' );
		return is_array( $prev ) ? $prev : array();
	}

	$body = json_decode( wp_remote_retrieve_body( $res ), true );
	$data = ( is_array( $body ) && isset( $body['data'] ) && is_array( $body['data'] ) ) ? $body['data'] : array();
	set_transient( $key, $data, $ttl );
	set_transient( $key . '_data', $data, DAY_IN_SECONDS ); // long-lived fallback
	$tag = wp_remote_retrieve_header( $res, 'etag' );
	if ( $tag ) { set_transient( $etag_key, $tag, DAY_IN_SECONDS ); }
	return $data;
}

function nfs_get_updates( $project = '', $limit = 60 ) {
	$path = '/api/feed/v1/updates?limit=' . (int) $limit;
	if ( $project ) { $path .= '&project=' . rawurlencode( $project ); }
	return nfs_feed_get( $path, NFS_FEED_TTL_UPDATES );
}
function nfs_get_jobs( $source = '', $full = false ) {
	$path = '/api/feed/v1/jobs';
	$q = array();
	if ( $source ) { $q[] = 'source=' . rawurlencode( $source ); }
	if ( $full )   { $q[] = 'full=1'; }
	if ( $q ) { $path .= '?' . implode( '&', $q ); }
	return nfs_feed_get( $path, NFS_FEED_TTL_JOBS );
}

/* ---- project_id slug -> display name (keep in sync with automation) ---- */
function nfs_project_names() {
	return array(
		'ciyota'     => 'Not For Sale Uganda',
		'blue-dragon'=> 'Not For Sale Vietnam',
		'surfers'    => 'Not For Sale South Africa',
		'codel'      => 'Not For Sale DRC',
		'vcdf'       => 'Not For Sale Thailand',
		'dignita'    => 'Not For Sale Netherlands',
		'fair'       => 'Not For Sale Netherlands (FAIR)',
		'afimad'     => 'Not For Sale Peru',
		'rebbl'      => 'REBBL',
		'regenerate' => 'Regenerate Technology Global',
		'm2i'        => 'M2i Global',
	);
}
function nfs_project_name( $slug ) {
	$m = nfs_project_names();
	return isset( $m[ $slug ] ) ? $m[ $slug ] : $slug;
}
/** Country (WP project title) -> automation project_id, default mapping. */
function nfs_country_to_automation( $country ) {
	$m = array(
		'Uganda'=>'ciyota', 'DR Congo'=>'codel', 'Vietnam'=>'blue-dragon',
		'South Africa'=>'surfers', 'Mozambique'=>'surfers',
		'Thailand'=>'vcdf', 'Laos'=>'vcdf', 'Myanmar'=>'vcdf',
		'Netherlands'=>'dignita', 'Peru'=>'afimad',
	);
	return isset( $m[ $country ] ) ? $m[ $country ] : '';
}

/* ===================== PROJECT: field updates ===================== */
function nfs_render_project_automation( $post_id, $country = '' ) {
	$slug = function_exists( 'get_field' ) ? get_field( 'automation_slug', $post_id ) : '';
	if ( ! $slug ) { $slug = nfs_country_to_automation( $country ); }
	if ( ! $slug ) { return ''; }

	$updates = nfs_get_updates( $slug, 24 );
	if ( ! is_array( $updates ) || ! $updates ) { return ''; }

	// group by month (data is newest-first)
	$groups = array();
	foreach ( $updates as $u ) {
		$ts = ! empty( $u['posted_at'] ) ? strtotime( $u['posted_at'] ) : false;
		$mk = $ts ? gmdate( 'Y-m', $ts ) : 'other';
		$groups[ $mk ][] = $u;
	}
	$blocks = '';
	foreach ( $groups as $mk => $items ) {
		$label = ( 'other' === $mk ) ? '' : gmdate( 'F Y', strtotime( $mk . '-01' ) );
		$cards = '';
		foreach ( $items as $u ) {
			$date  = ! empty( $u['posted_at'] ) ? esc_html( date_i18n( 'j M Y', strtotime( $u['posted_at'] ) ) ) : '';
			$img   = '';
			if ( ! empty( $u['image_url'] ) ) {
				$img = '<div class="uimg"><img src="' . esc_url( $u['image_url'] ) . '" alt="" loading="lazy"></div>';
			}
			$title = ! empty( $u['title'] ) ? '<h4 class="utitle">' . esc_html( $u['title'] ) . '</h4>' : '';
			$body  = ! empty( $u['body'] ) ? esc_html( $u['body'] ) : '';
			$don   = ! empty( $u['donation_url'] ) ? '<a class="more" href="' . esc_url( $u['donation_url'] ) . '" target="_blank" rel="noopener">Support this project &rarr;</a>' : '';
			$likes = isset( $u['like_count'] ) ? (int) $u['like_count'] : 0;
			$shares= isset( $u['share_count'] ) ? (int) $u['share_count'] : 0;
			$cards .= '<div class="ucard">' . $img . '<div class="ubody"><div class="date">' . $date . '</div>'
				. $title . '<p>' . $body . '</p>' . $don
				. '<div class="foot"><span>&#9825; ' . $likes . '</span><span>&#8599; ' . $shares . '</span></div></div></div>';
		}
		$blocks .= ( $label ? '<div class="month"><span>' . esc_html( $label ) . '</span></div>' : '' ) . '<div class="ugrid">' . $cards . '</div>';
	}

	return '<section class="nfs-auto"><div class="wrap"><section class="nfs-updates">'
		. '<div class="uh"><h2>Field updates</h2><div class="meta">Posts from the field team</div></div>'
		. $blocks . '</section></div></section>';
}

/* ===================== JOBS ===================== */
function nfs_render_jobs() {
	$jobs = nfs_get_jobs( '', false ); // summary only

	$head = '<section class="pagehead"><div class="wrap"><div class="eyebrow fade"><span class="dash"></span>Open positions</div>'
		. '<h1 class="fade">Job <em>Opportunities</em></h1>'
		. '<p class="lede fade">Open positions across our team and partner coalition. Search or filter, then open any role to read the summary and apply.</p></div></section>';

	if ( ! is_array( $jobs ) || ! $jobs ) {
		$base = nfs_get( 'feed_base' );
		$msg = $base ? 'No open positions right now. Please check back soon.' : 'Automation base URL not set. Add it in NFS Settings.';
		return $head . '<div class="wrap"><p style="padding:40px 0;color:var(--muted)">' . esc_html( $msg ) . '</p></div>';
	}

	// facets from data
	$types = array(); $sources = array();
	foreach ( $jobs as $j ) {
		if ( ! empty( $j['type'] ) ) { $types[ $j['type'] ] = 1; }
		if ( ! empty( $j['source'] ) ) { $sources[ $j['source'] ] = 1; }
	}
	$types = array_keys( $types ); sort( $types );
	$sources = array_keys( $sources ); sort( $sources );

	$typeSel = '<select class="jf" data-key="type"><option value="">Any type</option>';
	foreach ( $types as $t ) { $typeSel .= '<option value="' . esc_attr( $t ) . '">' . esc_html( $t ) . '</option>'; }
	$typeSel .= '</select>';
	$srcSel = '<select class="jf" data-key="source"><option value="">Any source</option>';
	foreach ( $sources as $sv ) { $srcSel .= '<option value="' . esc_attr( $sv ) . '">' . esc_html( ucfirst( $sv ) ) . '</option>'; }
	$srcSel .= '</select>';

	$total = count( $jobs );
	$rows = '';
	foreach ( $jobs as $j ) {
		$title = isset( $j['title'] ) ? $j['title'] : '';
		$type  = isset( $j['type'] ) ? $j['type'] : '';
		$loc   = isset( $j['location'] ) ? $j['location'] : '';
		$src   = isset( $j['source'] ) ? $j['source'] : '';
		$org   = ! empty( $j['partner_name'] ) ? $j['partner_name'] : ( 'nfs' === $src ? 'Not For Sale' : '' );
		$apply = isset( $j['linkedin_url'] ) ? $j['linkedin_url'] : '';
		$posted= ! empty( $j['posted_at'] ) ? date_i18n( 'M j', strtotime( $j['posted_at'] ) ) : '';
		$sum   = ! empty( $j['description_summary'] ) ? $j['description_summary'] : ( ! empty( $j['description_excerpt'] ) ? $j['description_excerpt'] : '' );
		$hay   = strtolower( trim( $title . ' ' . $loc . ' ' . $org ) );

		$detail = '<div class="jdetail"><div class="jdwrap">'
			. ( $sum ? '<p class="jdsum">' . esc_html( $sum ) . '</p>' : '<p class="jdsum" style="color:var(--muted)">Summary coming soon. Open the full posting to read more.</p>' )
			. ( $apply ? '<a class="btn btn-orange japply" href="' . esc_url( $apply ) . '" target="_blank" rel="noopener">View full role &amp; apply</a>' : '' )
			. '</div></div>';

		$rows .= '<div class="jrow" data-type="' . esc_attr( $type ) . '" data-source="' . esc_attr( $src ) . '" data-text="' . esc_attr( $hay ) . '">'
			. '<div class="jmain"><div class="jtitle">' . esc_html( $title ) . '</div>'
			. '<div class="jorg">' . esc_html( $org ) . ( $src ? ' <span class="rel">' . esc_html( ucfirst( $src ) ) . '</span>' : '' ) . '</div></div>'
			. '<div class="jtype"><span class="chip">' . esc_html( $type ) . '</span></div>'
			. '<div class="jloc">' . esc_html( $loc ) . '</div>'
			. '<div class="jposted">' . esc_html( $posted ) . '</div>'
			. '<button class="jexp" aria-label="Toggle summary">&#9662;</button>'
			. $detail . '</div>';
	}

	ob_start(); ?>
	<div class="filterbar jbar"><div class="wrap fb">
		<div class="jfilters">
			<input class="jsearch" type="search" placeholder="Search role, location, organization...">
			<?php echo $typeSel . $srcSel; // phpcs:ignore ?>
			<button class="jclear" type="button">Clear</button>
		</div>
		<div class="count"><span class="jcount"><?php echo (int) $total; ?></span> of <?php echo (int) $total; ?></div>
	</div></div>
	<div class="wrap"><div class="jtable">
		<div class="jhead"><span>Role</span><span>Type</span><span>Location</span><span>Posted</span><span></span></div>
		<?php echo $rows; // phpcs:ignore ?>
	</div></div>
	<script>
	(function(){
	 var sc=document.currentScript, root=sc.parentNode;
	 var rows=[].slice.call(root.querySelectorAll('.jrow')),
	     search=root.querySelector('.jsearch'),
	     sels=[].slice.call(root.querySelectorAll('.jf')),
	     cnt=root.querySelector('.jcount'),
	     clr=root.querySelector('.jclear');
	 function apply(){
	   var q=(search.value||'').toLowerCase().trim(), f={};
	   sels.forEach(function(s){f[s.getAttribute('data-key')]=s.value;});
	   var n=0;
	   rows.forEach(function(r){
	     var ok=(!q||r.getAttribute('data-text').indexOf(q)>-1)
	       &&(!f.type||r.getAttribute('data-type')===f.type)
	       &&(!f.source||r.getAttribute('data-source')===f.source);
	     r.style.display=ok?'':'none'; if(ok)n++;
	   });
	   if(cnt)cnt.textContent=n;
	 }
	 search&&search.addEventListener('input',apply);
	 sels.forEach(function(s){s.addEventListener('change',apply);});
	 clr&&clr.addEventListener('click',function(){search.value='';sels.forEach(function(s){s.value='';});apply();});
	 root.addEventListener('click',function(e){
	   if(e.target.closest('a'))return;
	   var row=e.target.closest('.jrow'); if(!row||!root.querySelector('.jtable').contains(row))return;
	   row.classList.toggle('open');
	 });
	})();
	</script>
	<?php
	return $head . ob_get_clean();
}

add_action( 'init', function () {
	register_block_type( 'nfs/jobs', array( 'render_callback' => 'nfs_render_jobs' ) );
} );
