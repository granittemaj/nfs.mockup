<?php
/**
 * NFS Core - ACF Field Groups
 * Registered in PHP and guarded so the plugin works even before ACF is active.
 * Uses only free-tier ACF field types (no Repeater/Flexible) for portability.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'acf/init', 'nfs_core_register_fields' );

function nfs_core_register_fields() {

	if ( ! function_exists( 'acf_add_local_field_group' ) ) {
		return;
	}

	// ---- PROJECT ----
	acf_add_local_field_group( array(
		'key'    => 'group_nfs_project',
		'title'  => 'Project details',
		'fields' => array(
			array( 'key' => 'field_project_status', 'label' => 'Status', 'name' => 'status', 'type' => 'select',
				'choices' => array( 'Active programme' => 'Active programme', 'Completed' => 'Completed', 'Planned' => 'Planned' ),
				'default_value' => 'Active programme', 'ui' => 1 ),
			array( 'key' => 'field_project_since', 'label' => 'Since (year)', 'name' => 'since', 'type' => 'text', 'placeholder' => '2012' ),
			array( 'key' => 'field_project_focus', 'label' => 'Focus areas', 'name' => 'focus_areas', 'type' => 'textarea',
				'instructions' => 'One per line (e.g. Survivor care, Prevention, Reforestation).', 'new_lines' => 'br', 'rows' => 4 ),
			array( 'key' => 'field_project_flag', 'label' => 'Flag', 'name' => 'flag', 'type' => 'image',
				'instructions' => 'Optional country flag. Featured image is the project hero.', 'return_format' => 'url', 'preview_size' => 'thumbnail' ),
			array( 'key' => 'field_project_autoslug', 'label' => 'Automation project ID', 'name' => 'automation_slug', 'type' => 'text',
				'instructions' => 'The NFS Automation project_id that feeds field updates here (e.g. ciyota, blue-dragon, vcdf). Leave blank to use the built-in country mapping.' ),
		),
		'location' => array( array( array( 'param' => 'post_type', 'operator' => '==', 'value' => 'project' ) ) ),
		'menu_order' => 0,
		'position' => 'normal',
	) );

	// ---- PARTNER ----
	acf_add_local_field_group( array(
		'key'    => 'group_nfs_partner',
		'title'  => 'Partner details',
		'fields' => array(
			array( 'key' => 'field_partner_logo', 'label' => 'Logo', 'name' => 'logo', 'type' => 'image', 'return_format' => 'url', 'preview_size' => 'medium' ),
			array( 'key' => 'field_partner_url', 'label' => 'Website', 'name' => 'url', 'type' => 'url', 'placeholder' => 'https://' ),
			array( 'key' => 'field_partner_sector', 'label' => 'Sector', 'name' => 'sector', 'type' => 'text', 'placeholder' => 'Retail / Fashion' ),
			array( 'key' => 'field_partner_since', 'label' => 'Partner since (year)', 'name' => 'since', 'type' => 'text', 'placeholder' => '2019' ),
			array( 'key' => 'field_partner_blurb', 'label' => 'Short description', 'name' => 'blurb', 'type' => 'textarea', 'rows' => 3 ),
		),
		'location' => array( array( array( 'param' => 'post_type', 'operator' => '==', 'value' => 'partner' ) ) ),
		'menu_order' => 0,
		'position' => 'normal',
	) );

	// ---- STORY ----
	acf_add_local_field_group( array(
		'key'    => 'group_nfs_story',
		'title'  => 'Story details',
		'fields' => array(
			array( 'key' => 'field_story_dek', 'label' => 'Dek (standfirst)', 'name' => 'dek', 'type' => 'text',
				'instructions' => 'The supporting line shown under the headline.' ),
			array( 'key' => 'field_story_read', 'label' => 'Read time (minutes)', 'name' => 'read_time', 'type' => 'number', 'min' => 1, 'placeholder' => '6' ),
			array( 'key' => 'field_story_featured', 'label' => 'Featured story', 'name' => 'is_featured', 'type' => 'true_false', 'ui' => 1,
				'instructions' => 'Show as the lead story on the homepage / news index.' ),
			array( 'key' => 'field_story_cover_style', 'label' => 'Cover style', 'name' => 'cover_style', 'type' => 'select',
				'instructions' => 'How the cover image is built. Leave on category default to follow NFS Settings.',
				'choices' => array( '' => 'Use category default', 'auto' => 'Auto (photo, else scene)', 'photo' => 'Photo', 'scene' => 'Scene', 'blend' => 'Blend (photo + scene)' ),
				'default_value' => '', 'allow_null' => 0, 'ui' => 1 ),
			array( 'key' => 'field_story_blend_treat', 'label' => 'Blend treatment', 'name' => 'blend_treatment', 'type' => 'select',
				'instructions' => 'Used when the cover style is Blend.',
				'choices' => array( '' => 'Category default', 'duotone' => 'Duotone', 'card' => 'Card', 'grade' => 'Grade' ),
				'default_value' => '', 'allow_null' => 0,
				'conditional_logic' => array( array( array( 'field' => 'field_story_cover_style', 'operator' => '==', 'value' => 'blend' ) ) ) ),
			array( 'key' => 'field_story_scene_pal', 'label' => 'Scene palette', 'name' => 'scene_palette', 'type' => 'select',
				'instructions' => 'Override the auto palette for the generated scene.',
				'choices' => array( '' => 'Auto (by theme)', 'clay' => 'Clay', 'teal' => 'Teal', 'green' => 'Green', 'slate' => 'Slate' ),
				'default_value' => '', 'allow_null' => 0 ),
		),
		'location' => array( array( array( 'param' => 'post_type', 'operator' => '==', 'value' => 'story' ) ) ),
		'menu_order' => 0,
		'position' => 'side',
	) );

	// ---- TEAM MEMBER ----
	acf_add_local_field_group( array(
		'key'    => 'group_nfs_team',
		'title'  => 'Team member details',
		'fields' => array(
			array( 'key' => 'field_team_role', 'label' => 'Role', 'name' => 'role', 'type' => 'text', 'placeholder' => 'Co-Founder' ),
			array( 'key' => 'field_team_location', 'label' => 'Location', 'name' => 'location', 'type' => 'text', 'placeholder' => 'San Francisco, USA' ),
			array( 'key' => 'field_team_type', 'label' => 'Type', 'name' => 'member_type', 'type' => 'select',
				'choices' => array( 'Founder' => 'Founder', 'Director' => 'Director' ), 'default_value' => 'Director', 'ui' => 1 ),
		),
		'location' => array( array( array( 'param' => 'post_type', 'operator' => '==', 'value' => 'team_member' ) ) ),
		'menu_order' => 0,
		'position' => 'normal',
	) );
}
