<?php
/**
 * NFS Core - server-rendered blocks (content binding).
 * Outputs the approved prototype markup populated from real CPT + ACF data.
 * Start: single Story. Same pattern will cover project/partner/team/archives.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Category colour for a theme term name. */
function nfs_theme_color( $name ) {
	$m = array(
		'Human Trafficking' => '#c46f49',
		'Social Innovation' => '#4f8e92',
		'Social Enterprise' => '#4f8e92',
		'Ecocide'           => '#5b7747',
		'Cyber Scams'       => '#62808d',
	);
	return isset( $m[ $name ] ) ? $m[ $name ] : '#F5821F';
}

/** Read time: ACF field if set, else estimate from word count. */
function nfs_story_read_time( $id ) {
	if ( function_exists( 'get_field' ) ) {
		$rt = get_field( 'read_time', $id );
		if ( $rt ) { return (int) $rt; }
	}
	$words = str_word_count( wp_strip_all_tags( get_post_field( 'post_content', $id ) ) );
	return max( 1, (int) ceil( $words / 200 ) );
}

/** Initials avatar (matches the prototype's circular avatar). */
function nfs_initials( $name ) {
	$parts = preg_split( '/\s+/', trim( $name ) );
	$ini = '';
	foreach ( array_slice( $parts, 0, 2 ) as $p ) { $ini .= mb_substr( $p, 0, 1 ); }
	return strtoupper( $ini );
}
function nfs_avatar_html( $name, $color, $size ) {
	return '<div class="av" style="width:' . $size . 'px;height:' . $size . 'px;border-radius:50%;display:grid;place-items:center;background:' . esc_attr( $color ) . ';color:#fff;font-weight:700;font-size:' . round( $size / 2.6 ) . 'px">' . esc_html( nfs_initials( $name ) ) . '</div>';
}

/** Render: single Story. */
function nfs_render_story_single() {
	if ( ! is_singular( 'story' ) ) { return ''; }
	$id = get_the_ID();

	$title  = get_the_title( $id );
	$body   = apply_filters( 'the_content', get_post_field( 'post_content', $id ) );
	$dek    = function_exists( 'get_field' ) ? get_field( 'dek', $id ) : '';
	if ( ! $dek ) { $dek = get_the_excerpt( $id ); }

	$terms     = get_the_terms( $id, 'nfs_theme' );
	$theme_name = ( $terms && ! is_wp_error( $terms ) ) ? $terms[0]->name : '';
	$col       = nfs_theme_color( $theme_name );
	$rt        = nfs_story_read_time( $id );
	$author    = get_the_author_meta( 'display_name', get_post_field( 'post_author', $id ) );
	$date      = get_the_date( '', $id );

	$tag = $theme_name
		? '<span class="tag cat" style="color:' . esc_attr( $col ) . '"><span class="dot" style="background:' . esc_attr( $col ) . '"></span>' . esc_html( $theme_name ) . '</span>'
		: '';

	$cover = '<div class="wrap"><div class="postcover fade">' . nfs_cover( $id, 'cover' ) . '</div></div>';

	// Related (3 most recent other stories)
	$relhtml = '';
	$rel = new WP_Query( array(
		'post_type'           => 'story',
		'posts_per_page'      => 3,
		'post__not_in'        => array( $id ),
		'orderby'             => 'date',
		'order'               => 'DESC',
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	) );
	while ( $rel->have_posts() ) {
		$rel->the_post();
		$rid = get_the_ID();
		$rt2 = get_the_terms( $rid, 'nfs_theme' );
		$rn  = ( $rt2 && ! is_wp_error( $rt2 ) ) ? $rt2[0]->name : '';
		$rc  = nfs_theme_color( $rn );
		$img = nfs_cover( $rid, 'card' );
		$rtag = $rn ? '<span class="tag cat" style="color:' . esc_attr( $rc ) . '"><span class="dot" style="background:' . esc_attr( $rc ) . '"></span>' . esc_html( $rn ) . '</span>' : '';
		$relhtml .= '<a class="art" href="' . esc_url( get_permalink( $rid ) ) . '"><div class="ph">' . $img . '</div><div class="b">' . $rtag . '<div class="t">' . esc_html( get_the_title( $rid ) ) . '</div><div class="am"><span>' . nfs_story_read_time( $rid ) . ' min read</span><span>&rarr;</span></div></div></a>';
	}
	wp_reset_postdata();

	ob_start(); ?>
	<article>
		<div class="postwrap"><header class="posthead fade">
			<?php echo $tag; // phpcs:ignore ?>
			<h1><?php echo esc_html( $title ); ?></h1>
			<?php if ( $dek ) : ?><p class="dek"><?php echo esc_html( $dek ); ?></p><?php endif; ?>
			<div class="byline"><?php echo nfs_avatar_html( $author, $col, 42 ); // phpcs:ignore ?><div>By <b><?php echo esc_html( $author ); ?></b> &middot; <?php echo (int) $rt; ?> min read &middot; <?php echo esc_html( $date ); ?></div></div>
		</header></div>

		<?php echo $cover; // phpcs:ignore ?>

		<div class="postwrap">
			<div class="article fade"><?php echo $body; // phpcs:ignore ?></div>
			<div class="authorbox"><?php echo nfs_avatar_html( $author, $col, 64 ); // phpcs:ignore ?><div><h4><?php echo esc_html( $author ); ?></h4><div class="r">Not For Sale</div></div></div>
		</div>

		<?php if ( $relhtml ) : ?>
		<section class="sec"><div class="wrap"><div class="sec-h fade"><div><h2>Related Stories</h2></div></div><div class="related fade"><?php echo $relhtml; // phpcs:ignore ?></div></div></section>
		<?php endif; ?>
	</article>
	<?php
	return ob_get_clean();
}

add_action( 'init', function () {
	register_block_type( 'nfs/story-single', array(
		'render_callback' => 'nfs_render_story_single',
	) );
} );

/* ===================== PROJECTS ===================== */

function nfs_project_meta( $id ) {
	$terms  = get_the_terms( $id, 'region' );
	$region = ( $terms && ! is_wp_error( $terms ) ) ? $terms[0]->name : '';
	$get = function ( $k ) use ( $id ) {
		if ( function_exists( 'get_field' ) ) { $v = get_field( $k, $id ); if ( $v ) { return $v; } }
		$m = get_post_meta( $id, $k, true ); return $m ? $m : '';
	};
	$status = $get( 'status' ); if ( ! $status ) { $status = 'Active programme'; }
	$since  = $get( 'since' );  if ( ! $since ) { $since = nfs_region_since( $region ); }
	$focusR = $get( 'focus_areas' );
	$focus  = $focusR ? array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $focusR ) ) ) : nfs_region_focus( $region );
	return array( 'region'=>$region, 'status'=>$status, 'since'=>$since, 'focus'=>$focus, 'slug'=>sanitize_title( get_the_title( $id ) ) );
}

function nfs_project_card( $id ) {
	$m = nfs_project_meta( $id );
	$flag = nfs_flag_img( $m['slug'], 'flag' );
	return '<a class="pcard" data-region="' . esc_attr( $m['region'] ) . '" href="' . esc_url( get_permalink( $id ) ) . '">'
		. '<div class="ph">' . nfs_cover( $id, 'card' ) . $flag . '</div>'
		. '<div class="meta"><div class="reg">' . esc_html( $m['region'] ) . '</div>'
		. '<div class="name">' . esc_html( get_the_title( $id ) ) . '</div>'
		. '<span class="go">View project &rarr;</span></div></a>';
}

function nfs_render_projects_archive() {
	$q = new WP_Query( array( 'post_type'=>'project', 'posts_per_page'=>-1, 'orderby'=>'title', 'order'=>'ASC', 'no_found_rows'=>true ) );
	$total = $q->post_count;
	$regions = array(); $cards = '';
	while ( $q->have_posts() ) { $q->the_post(); $m = nfs_project_meta( get_the_ID() ); if ( $m['region'] ) { $regions[ $m['region'] ] = 1; } $cards .= nfs_project_card( get_the_ID() ); }
	wp_reset_postdata();
	$regs = array_keys( $regions ); sort( $regs );

	$pills = '<button class="fbtn on" data-region="all">All</button>';
	foreach ( $regs as $r ) { $pills .= '<button class="fbtn" data-region="' . esc_attr( $r ) . '">' . esc_html( $r ) . '</button>'; }

	ob_start(); ?>
	<section class="pagehead"><div class="wrap">
		<div class="eyebrow fade"><span class="dash"></span><?php echo (int) $total; ?> countries &middot; <?php echo count( $regs ); ?> regions</div>
		<h1 class="fade">Our <em>Projects</em></h1>
		<p class="lede fade">We have supported over 500,000 survivors and at-risk individuals worldwide. Explore the mission, challenges, and impact in every region we serve.</p>
	</div></section>
	<div class="filterbar"><div class="wrap fb">
		<div class="filters nfs-pfilters"><?php echo $pills; // phpcs:ignore ?></div>
		<div class="count nfs-pcount"><?php echo (int) $total; ?> projects</div>
	</div></div>
	<div class="wrap"><div class="pgrid nfs-pgrid"><?php echo $cards; // phpcs:ignore ?></div></div>
	<script>
	(function(){var root=document.currentScript.previousElementSibling||document;
	 var pills=document.querySelectorAll('.nfs-pfilters .fbtn'),cards=document.querySelectorAll('.nfs-pgrid .pcard'),cnt=document.querySelector('.nfs-pcount');
	 pills.forEach(function(b){b.addEventListener('click',function(){
	   pills.forEach(function(x){x.classList.toggle('on',x===b);});var r=b.getAttribute('data-region'),n=0;
	   cards.forEach(function(c){var show=(r==='all'||c.getAttribute('data-region')===r);c.style.display=show?'':'none';if(show)n++;});
	   if(cnt)cnt.textContent=n+' projects';
	 });});})();
	</script>
	<?php
	return ob_get_clean();
}

function nfs_render_project_single() {
	if ( ! is_singular( 'project' ) ) { return ''; }
	$id = get_the_ID();
	$m  = nfs_project_meta( $id );
	$title = get_the_title( $id );
	$body  = apply_filters( 'the_content', get_post_field( 'post_content', $id ) );
	$flag  = nfs_flag_img( $m['slug'], 'flag' );

	$focusTags = '';
	foreach ( $m['focus'] as $f ) { $focusTags .= '<span class="chip">' . esc_html( $f ) . '</span>'; }

	// related: same region, others
	$rel = new WP_Query( array( 'post_type'=>'project', 'posts_per_page'=>3, 'post__not_in'=>array( $id ),
		'tax_query'=>array( array( 'taxonomy'=>'region', 'field'=>'name', 'terms'=>$m['region'] ) ),
		'orderby'=>'rand', 'no_found_rows'=>true ) );
	$relhtml = '';
	while ( $rel->have_posts() ) { $rel->the_post(); $relhtml .= nfs_project_card( get_the_ID() ); }
	wp_reset_postdata();

	ob_start(); ?>
	<section class="dhero">
		<div class="ph"><?php echo nfs_cover( $id, 'cover' ); // phpcs:ignore ?></div>
		<div class="wrap in">
			<div class="kicker"><span class="dash"></span>Programme</div>
			<?php if ( $flag ) : ?><div class="flagrow"><?php echo $flag; // phpcs:ignore ?></div><?php endif; ?>
			<h1><?php echo esc_html( $title ); ?></h1>
			<p class="lede">How we work alongside this community to prevent exploitation, support survivors, and build lasting alternatives to trafficking.</p>
		</div>
	</section>
	<div class="wrap"><div class="detail">
		<div class="main">
			<?php if ( $focusTags ) : ?><div class="tags"><?php echo $focusTags; // phpcs:ignore ?></div><?php endif; ?>
			<div class="article fade"><?php echo $body; // phpcs:ignore ?></div>
		</div>
		<aside class="factbox fade">
			<h4>At a glance</h4>
			<div class="frow"><span class="k">Region</span><span class="v"><?php echo esc_html( $m['region'] ); ?></span></div>
			<div class="frow"><span class="k">Status</span><span class="v"><?php echo esc_html( $m['status'] ); ?></span></div>
			<div class="frow"><span class="k">Since</span><span class="v"><?php echo esc_html( $m['since'] ); ?></span></div>
			<div class="frow"><span class="k">Focus</span><span class="v"><?php echo esc_html( implode( ', ', $m['focus'] ) ); ?></span></div>
			<a class="btn btn-orange" href="#">Support this project &rarr;</a>
			<a class="btn btn-light" href="<?php echo esc_url( get_post_type_archive_link( 'project' ) ); ?>" style="width:100%;margin-top:10px">All projects</a>
		</aside>
	</div></div>
	<?php echo nfs_render_project_automation( $id, get_the_title( $id ) ); // phpcs:ignore ?>

	<?php if ( $relhtml ) : ?>
	<section class="sec"><div class="wrap"><div class="sec-h fade"><div><h2>More projects in <?php echo esc_html( $m['region'] ); ?></h2></div><a class="btn btn-ink" href="<?php echo esc_url( get_post_type_archive_link( 'project' ) ); ?>">View all &rarr;</a></div>
		<div class="pgrid nfs-pgrid"><?php echo $relhtml; // phpcs:ignore ?></div>
	</div></section>
	<?php endif;
	return ob_get_clean();
}

add_action( 'init', function () {
	register_block_type( 'nfs/projects-archive', array( 'render_callback' => 'nfs_render_projects_archive' ) );
	register_block_type( 'nfs/project-single', array( 'render_callback' => 'nfs_render_project_single' ) );
} );
