# NFS Core

Content model for the Not For Sale website. Built by PAPINGU. Keeping this in a plugin (not the
theme) means your content and structure survive any theme change.

## What it registers
**Post types**
| Type | Slug / URL | Holds |
|---|---|---|
| Story | `/news/` | News, investigations, explainers |
| Project | `/projects/` | Country programmes |
| Partner | `/partners/` | Corporate partners |
| Team Member | `/team/` | Founders + directors |

**Taxonomies**
| Taxonomy | On | Default terms (seeded) |
|---|---|---|
| Theme (`nfs_theme`) | Story | Human Trafficking, Social Innovation, Ecocide, Cyber Scams |
| Region | Project | Americas, Africa, Europe, Asia-Pacific |

**Fields (ACF)**
- Project: status, since, focus areas, flag (featured image = hero)
- Partner: logo, website, sector, since, blurb
- Story: dek, read time, featured (featured image = cover; Theme taxonomy)
- Team Member: role, location, type (Founder / Director); featured image = photo

Only free-tier ACF field types are used, so it works with **ACF (free)** or **Secure Custom Fields**.

## Install
1. Zip this folder (or use `nfs-core.zip`).
2. Plugins → Add New → Upload Plugin → choose the zip → Activate.
3. Install + activate **ACF** (or Secure Custom Fields) so the fields appear. An admin notice reminds you if it is missing.
4. Permalinks flush automatically on activation. If a 404 appears on a new post type, go to Settings → Permalinks → Save once.

## Notes
- Field groups also save to `acf-json/` so they are version-controlled and editable in the ACF UI.
- The PAPINGU theme styles these types. Single/archive templates that pull these fields are the next build step.
- Project updates synced from automation.wearenotforsale.org should map to the **Story** type (or a dedicated type) and, ideally, link to a parent **Project**. Wire that once the sync plugin is confirmed.
