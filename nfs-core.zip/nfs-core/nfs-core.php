<?php
/**
 * Plugin Name:       NFS Core
 * Plugin URI:        https://papingu.com
 * Description:       Content model for the Not For Sale website: custom post types (Project, Partner, Story, Team Member), taxonomies (Theme, Region), and ACF field groups. Kept in a plugin so content survives theme changes. Built by PAPINGU.
 * Version:           1.6.4
 * Author:            PAPINGU L.L.C.
 * Author URI:        https://papingu.com
 * License:           GPL-2.0-or-later
 * Text Domain:       nfs-core
 * Requires at least: 6.5
 * Requires PHP:      7.4
 * Update URI:        https://github.com/granittemaj/nfs-core-papingu
 * GitHub Plugin URI: granittemaj/nfs-core-papingu
 * Primary Branch:    main
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'NFS_CORE_VERSION', '1.6.4' );
define( 'NFS_CORE_DIR', plugin_dir_path( __FILE__ ) );

require_once NFS_CORE_DIR . 'includes/post-types.php';
require_once NFS_CORE_DIR . 'includes/taxonomies.php';
require_once NFS_CORE_DIR . 'includes/settings.php';
require_once NFS_CORE_DIR . 'includes/acf-fields.php';
require_once NFS_CORE_DIR . 'includes/recaptcha.php';
require_once NFS_CORE_DIR . 'includes/contact.php';
require_once NFS_CORE_DIR . 'includes/scene.php';
require_once NFS_CORE_DIR . 'includes/flags.php';
require_once NFS_CORE_DIR . 'includes/seed.php';
require_once NFS_CORE_DIR . 'includes/feeds.php';
require_once NFS_CORE_DIR . 'includes/blocks.php';

/**
 * Tell ACF to load and save field groups as JSON inside this plugin,
 * so the content model is version-controlled and travels with the plugin.
 */
add_filter( 'acf/settings/save_json', function () {
	return NFS_CORE_DIR . 'acf-json';
} );
add_filter( 'acf/settings/load_json', function ( $paths ) {
	$paths[] = NFS_CORE_DIR . 'acf-json';
	return $paths;
} );

/**
 * Activation: register everything, then flush rewrite rules so the
 * custom permalinks (/projects/, /partners/, /news/, /team/) work immediately.
 */
register_activation_hook( __FILE__, function () {
	nfs_core_register_post_types();
	nfs_core_register_taxonomies();
	flush_rewrite_rules();
} );

register_deactivation_hook( __FILE__, function () {
	flush_rewrite_rules();
} );

/**
 * Admin notice if ACF is not active (fields will not appear without it).
 */
add_action( 'admin_notices', function () {
	if ( ! function_exists( 'acf_add_local_field_group' ) ) {
		echo '<div class="notice notice-warning"><p><strong>NFS Core:</strong> Advanced Custom Fields (or Secure Custom Fields) is not active. Post types work, but the custom fields will not show until you install and activate it.</p></div>';
	}
} );
